package com.cg.java.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.java.Exception.EmpException;
import com.cg.java.dao.EmpDao;
import com.cg.java.dto.EmployeeDTO;
@Service("empService")
public class EmpServiceImpl implements EmpService{
	//@Autowired
	private EmpDao dao;
	
	public EmpDao getDao() {
		return dao;
	}
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}
	
	public List<EmployeeDTO> getEmpList() throws EmpException {
		return dao.getEmpList();
	}
	
}
