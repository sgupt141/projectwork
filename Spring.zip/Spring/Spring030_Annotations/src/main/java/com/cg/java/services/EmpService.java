package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
/* 
 * Bean Lifecycle method
	@PostConstruct: An annotation given by java.
		It declares an init method for a bean.
		After creating a bean, Spring context calls this method automatically.
		This approach allows naming the method according to choice.
	@preDestroy: An annotation given by java
		It declared a finalizing method for a bean.
		At the time of bean removed from spring context,\
			this method is automatically called. It is to clean resource.
		Method name can be different as per the aim of the method.
	Both annotations come from java annotations.
	Both Ideally should be preferred over use of spring Bean Life cycle initialization.
	
	@Scope : To declare 'Singleton' or 'Prototype' for a bean.
	@Scope('Singleton') or @Scope('Prototype')
	
	Each bean by default is created eagerly i.e., at the time of creation of
	@Lazy(false): By default creates bean eagerly. 
	@Lazy(true): Creates a bean lazily only on demand.
	
	@Component: To declare a bean...
		The sub-annotations are for documentation purpose.
		@Repository: To declare DAO classes as bean.
		@Service: To declare business logic/service beans.
		@Controller: An annotation to declare controlling classes in spring MVC 
		@RestController: An annotation to declare REST services from a class in spring REST
 */
@Service("empServices")
@Scope("singleton")
@Lazy(false) // By default false
public class EmpService { //implements InitializingBean, DisposableBean
	@Value("Capgemini, Pune")
	private String companyName;
	@Value("Talwade")
	private String address;
	//@Autowired
	private SalaryServices services;
	@Value("50000")
	private float yearlyPackage;
	//@Autowired // Constructor Injection
	public EmpService(String companyName, String address) {
		super();
		System.out.println("In two para constructor");
		this.companyName = companyName;
		this.address = address;
	}
	public EmpService(String companyName, String address, float yearlyPackage) {
		super();
		System.out.println("In three para constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlyPackage=yearlyPackage;
	}
	@Autowired // Constructor Injection
	public EmpService(SalaryServices services){
		//System.out.println("EmpService object created");
		this.services=services;
	}
	public String getMessage(){
		return "Welcome to Spring training: "+ companyName + " " + address;
	}
	public String getCompanyName() { // companyName = propertyName
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAddress() { // address
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public float getYearlyPackage() {
		return yearlyPackage;
	}
	public void setYearlyPackage(float yearlyPackage) {
		this.yearlyPackage = yearlyPackage;
	}
	public SalaryServices getServices() {
		return services;
	}
//	@Autowired  // Setter Injection
//	@Qualifier("salServices") // By Name
	// byType : Find the bean as per the type and not on 'Id'.
	// byName : Find the bean on the bases on ID.
	public void setServices(SalaryServices services) {
		this.services = services;
	}
	@PostConstruct
	public void initializeFormFile() throws Exception {
		System.out.println("In initializeFormFile()");		
	}
	@PreDestroy
	public void closeResource() throws Exception {
		System.out.println("In closeResource()");		
	}
//	@Override
//	public void destroy() throws Exception {
//		// TODO Auto-generated method stub
//		
//	}
//	@Override
//	public void afterPropertiesSet() throws Exception {
//		// TODO Auto-generated method stub
//		
//	}
}
