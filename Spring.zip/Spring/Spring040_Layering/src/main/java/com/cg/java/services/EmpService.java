package com.cg.java.services;

import java.util.List;

import com.cg.java.Exception.EmpException;
import com.cg.java.dto.EmployeeDTO;

public interface EmpService {
	public List<EmployeeDTO> getEmpList() throws EmpException;
}
