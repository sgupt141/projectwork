package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.Exception.EmpException;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;


public class Test040_Context {
		public static void main(String args[]){
			
			ApplicationContext ctx= new ClassPathXmlApplicationContext("springCore.xml");
		
			
			//EmpDaoImpl service1= (EmpDaoImpl)ctx.getBean("empDaoImpl");
			EmpService service1=(EmpService)ctx.getBean("EmpService");
			try {
				System.out.println(service1.getEmpList());
			} catch (EmpException e) {
				e.printStackTrace();
			}
		}

		
}
