package com.cg.java.services;

public class EmpService {
	private String companyName;
	private String address;
	private SalaryServices services;
	private float yearlyPackage;
	public EmpService(String companyName, String address, float yearlyPackage) {
		super();
		System.out.println("In two para constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlyPackage=yearlyPackage;
	}
	public EmpService(){
		System.out.println("EmpService object created");
	}
	public String getMessage(){
		return "Welcome to Spring training: "+ companyName + " " + address;
	}
	public String getCompanyName() { // companyName = propertyName
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAddress() { // address
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public SalaryServices getServices() {
		return services;
	}
	public void setServices(SalaryServices services) {
		this.services = services;
	}
	public float getYearlyPackage() {
		return yearlyPackage;
	}
	public void setYearlyPackage(float yearlyPackage) {
		this.yearlyPackage = yearlyPackage;
	}
}
