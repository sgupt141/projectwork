package com.cg.java.tests;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpService;
import com.cg.java.services.SalaryServices;
/*
The bean tag takes at least two attributes...
The class attributes: Represents fully qualified name of class
* 		the id attributes : to uniquely identify bean.
The classPathXmlApplicationContext
 		is a spring container implementing interface ApplicationContext
On creation of classPathXmlApplicationContext...
* 		Refers the configuration file and creates every bean declared there
*		Beans are of two types: Singleton and Prototype
*		Singleton: Object created only once. By default it is Singleton
*		Prototype: Object created as and when required.
Bean creation:
	Eager: all beans are created at the time of creation of spring context.
	Lazy: Beans are always created.
*	
	Prototype beans are always created lazily.
	Singleton: Eagerly/Lazily.
*/
public class Test010_Context {

	public static void main(String[] args) {
		// 1. Create spring context, spring container
		//BeanFactory factory = new XmlBeanFactory();
		// The ApplicationContext is modified version at BeanFactory.
		// From spring 4.3 onwards, BeanFactory is deprecated. 
		ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
		System.out.println("***********");
		EmpService service1 = (EmpService) ctx.getBean("services");
		EmpService service2 = (EmpService) ctx.getBean("services");
		System.out.println(service1.getMessage());
		System.out.println(service2.getMessage());
		System.out.println(service1.getAddress());
		//System.out.println(service1.getYearlyPackage());
		SalaryServices service= (SalaryServices)ctx.getBean("salServices");
		System.out.println(service.calcSalary());
	}
}
