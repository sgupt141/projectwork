package com.cg.java.dto;

public class EmpSal {
	private int empNo;
	private float gross;
	private float deduction;
	public EmpSal() {
		super();
	}
	public EmpSal(int empNo, float gross, float deduction) {
		super();
		this.empNo = empNo;
		this.gross = gross;
		this.deduction = deduction;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public float getGross() {
		return gross;
	}
	public void setGross(float gross) {
		this.gross = gross;
	}
	public float getDeduction() {
		return deduction;
	}
	public void setDeduction(float deduction) {
		this.deduction = deduction;
	}
	@Override
	public String toString() {
		return "EmpSal [empNo=" + empNo + ", gross=" + gross + ", deduction=" + deduction + "]";
	}
	
}
