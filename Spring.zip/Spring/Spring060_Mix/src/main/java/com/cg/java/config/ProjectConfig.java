package com.cg.java.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;
import com.cg.java.services.EmpServiceImpl;

/*
 * @Configuration: Class level. Declare a class as configuration class 
 * @Bean: Method level. Declares a method as a factory method.
 * 		(A method responsible for creating, initializing an object is a Factory method.)
 * 
 * The @Lazy and @Scope annotations are also allowed on factory methods.
 * 
 * Three approaches for bean configuration
 * 1. XML Configuration
 * 		Bean is declared using <bean> in spring XML configuration
 * 		Do not declare bean with annotation, componentScan and factory method
 * 2. Annotation: (@Component, @Repository, @Service)
 * 		Mention inn component scan either in java config or in XML
 * 		Do not declare bean in XML and Factory method
 * 3. Factory Method in JavaConfig class
 * 		Create a factory method in java config class
 * 		Do not annotate bean and thus no ComponentScan
 * 		Do not declare bean with <bean> in XML configuration. 
 * 
 * @ComponentScan: To mention packages to scan for annotated classes
 * @ImortResource: To import XML configuration.
 */

@Configuration
@ComponentScan("com.cg.java.services")
@ImportResource("springCore.xml")
public class ProjectConfig {
	
	@Autowired
	ApplicationContext ctx;
	
	// factory method for EmpDaoImpl
	@Bean("empDao")
	public EmpDao getEmpDao(){
		System.out.println("Bean created");
		return new EmpDaoImpl();
	}
}
