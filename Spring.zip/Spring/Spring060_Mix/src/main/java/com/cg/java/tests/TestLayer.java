package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.Exception.EmpException;
import com.cg.java.config.ProjectConfig;
import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;

public class TestLayer {
		public static void main(String args[]){
			ConfigurableApplicationContext ctx=new AnnotationConfigApplicationContext(ProjectConfig.class);
			//ApplicationContext ctx= new ClassPathXmlApplicationContext("springCore.xml");
			//EmpDaoImpl service1= (EmpDaoImpl)ctx.getBean("empDaoImpl");
			System.out.println("***********");
			EmpService ser1 = (EmpService) ctx.getBean("empService", EmpService.class);
			EmpService ser2 = (EmpService) ctx.getBean("empService", EmpService.class);
			//EmpService service1=(EmpService)ctx.getBean("EmpService");
			try {
				System.out.println(ser1.getEmpList());
				System.out.println(ser1.getEmpSalList());
				
				System.out.println("ser1: "+ ser1.hashCode());
				System.out.println("ser2: " + ser2.hashCode());
			} catch (EmpException e) {
				e.printStackTrace();
			}
		}	
}
