package com.cg.boot.Spring200_BootMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring200BootMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
