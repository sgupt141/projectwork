package com.cg.web.boot.dao;

import org.springframework.data.repository.CrudRepository;

import com.cg.web.boot.dto.*;
public interface EmpDao extends CrudRepository<Employee, Integer>{

}
