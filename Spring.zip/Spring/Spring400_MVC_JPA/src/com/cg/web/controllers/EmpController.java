package com.cg.web.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.dto.EmpDto;
import com.cg.core.services.EmpService;

// http://localhost:8090/Spring400_MVC_JPA/empService/home.do
@Controller
@RequestMapping("/empService")
public class EmpController {
	
	@Autowired
	private EmpService empService;
	@RequestMapping("/home.do")
	public String getHomePage(){
		return "Home";
	}
	
	@RequestMapping("/login.do")
	public String getLoginPage(){
		
		return "login";
	}
	
	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(
			@RequestParam("username") String username,
			@RequestParam("password") String password){
		
//		String username = req.getParameter("username");
//		String password = req.getParameter("password");
		String fullName = empService.authenticate(username,password);
		ModelAndView mv = null;
		if(fullName!=null)
		{
			mv= new ModelAndView("MainMenu");
			mv.addObject("fullName", fullName);
		}
		else
		{
			mv= new ModelAndView("login");
			mv.addObject("msg", "Authentication failed, Plz do agian");
		}
		return mv;
		//System.out.println("Username: "+ username+ " password: "+ password);
		//return "MainMenu";
	}
	@RequestMapping("/empList.do")
	public ModelAndView getEmpList(){
		
		List<EmpDto> empList = null;
		try {
			empList = empService.getEmpList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("empList", empList);
		mv.setViewName("EmpList");
		return mv;
	}
}
