package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
/* 
 *	The interface InitializingBean imposes implements of method afterPropertiesSet(), this method will call 
 *		automatically called after setting all properties.
 *
 *	The interface DisposableBean imposes implements of method destroy(), this method will call automatically 
 *		called while bean is removed from spring context.
 */
@Component("empServices")
public class EmpService implements InitializingBean, DisposableBean{
	@Value("Capgemini, Pune")
	private String companyName;
	@Value("Talwade")
	private String address;
	//@Autowired
	private SalaryServices services;
	@Value("50000")
	private float yearlyPackage;
	//@Autowired // Constructor Injection
	public EmpService(String companyName, String address) {
		super();
		System.out.println("In two para constructor");
		this.companyName = companyName;
		this.address = address;
	}
	public EmpService(String companyName, String address, float yearlyPackage) {
		super();
		System.out.println("In three para constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlyPackage=yearlyPackage;
	}
	@Autowired // Constructor Injection
	public EmpService(SalaryServices services){
		//System.out.println("EmpService object created");
		this.services=services;
	}
	public String getMessage(){
		return "Welcome to Spring training: "+ companyName + " " + address;
	}
	public String getCompanyName() { // companyName = propertyName
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getAddress() { // address
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public float getYearlyPackage() {
		return yearlyPackage;
	}
	public void setYearlyPackage(float yearlyPackage) {
		this.yearlyPackage = yearlyPackage;
	}
	public SalaryServices getServices() {
		return services;
	}
//	@Autowired  // Setter Injection
//	@Qualifier("salServices") // By Name
	// byType : Find the bean as per the type and not on 'Id'.
	// byName : Find the bean on the bases on ID.
	public void setServices(SalaryServices services) {
		this.services = services;
	}
	@PostConstruct
	public void afterPropertiesSet() throws Exception {
		System.out.println("In afterPropertiesSet()");		
	}
	@PreDestroy
	public void destroy() throws Exception {
		System.out.println("In destroy()");		
	}
}
