package com.cg.java.tests;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmpService;
import com.cg.java.services.SalaryServices;
/*
The bean declaration is done using @Component
The initial value can be hard-coded using @Value
There are three types of Injections......
		The field Injection: Give @Autowired to field.
		The Constructor Injection: Give @Autowired to Constructor.
		The Setter Injection: Give @Autowired to Setter method.
*/
public class Test010_Context {

	public static void main(String[] args) {
		// 1. Create spring context, spring container
		//BeanFactory factory = new XmlBeanFactory();
		// The ApplicationContext is modified version at BeanFactory.
		// From spring 4.3 onwards, BeanFactory is deprecated. 
		ApplicationContext ctx = new ClassPathXmlApplicationContext("springCore.xml");
		System.out.println("***********");
		EmpService service1 = (EmpService) ctx.getBean("empServices");
		EmpService service2 = (EmpService) ctx.getBean("empServices");
		System.out.println(service1.getMessage());
		System.out.println(service2.getMessage());
		System.out.println(service1.getAddress());
//		SalaryServices service= (SalaryServices)ctx.getBean("salServices");
//		System.out.println(service.calcSalary());
		System.out.println(service1.getYearlyPackage());
		ConfigurableApplicationContext cctx = (ConfigurableApplicationContext)ctx;
		cctx.close();
	}
}
