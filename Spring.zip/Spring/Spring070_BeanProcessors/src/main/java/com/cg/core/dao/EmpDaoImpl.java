package com.cg.core.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Repository("empDaoImpl")
public class EmpDaoImpl implements EmpDao{
	
		@Value("10")
		private int value;
		
		@Autowired
		private SalaryDao salDao;
		
		@Override
		public String toString() {
			return "EmpDaoImpl [value=" + value + "]";
		}
		public EmpDaoImpl(){
			System.out.println("EmpBean created");
		
	}
		public int getValue() {
			return 0;
		}
		public void setValue(int i) {
			
		}

}
