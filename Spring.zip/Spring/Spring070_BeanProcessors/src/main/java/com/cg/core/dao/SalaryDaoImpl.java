package com.cg.core.dao;

import org.springframework.stereotype.Repository;

@Repository
public class SalaryDaoImpl implements SalaryDao {

}
