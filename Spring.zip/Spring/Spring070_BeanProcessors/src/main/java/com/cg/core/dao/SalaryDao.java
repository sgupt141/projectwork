package com.cg.core.dao;


public interface SalaryDao {
		
		
}
