package com.cg.core.config;

import java.beans.PropertyDescriptor;

import org.springframework.beans.BeansException;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessor;
import org.springframework.stereotype.Component;

import com.cg.core.dao.EmpDao;
import com.cg.core.dao.EmpDaoImpl;

/*
 *  The BeanPostProcessors are created before all other beans.
 *  The PostProcessBeforeInstantiation() is called for creating EmpDao.
 *  If this method returns instance of EmpDaoImpl, Bean is created.
 *  If this method returns null, spring invokes its own bean creation mechanism and creates a bean . 
 *  
 *  BeanPostProcessor
 *  		postProcessBeforeInstantiation() : Works as Object Factory.
 *  				If it returns Null, Spring invokes default object creation mechanism
 *  		postProcessAfterInstantiation(): 
 *  						Returns 'false' : Bypasses data injection . This is known as Short Circuiting.
 *  						Returns 'true' :  Does Data Injection
 *  		postProcessProperties()
 *  		postProcessPropertyValues()
 *  
 *  		postProcessBeforeInitialization(): Executed before calling the PostConstruct or
 *  				Executed after value and reference injections. 
 *  		postProcessAfterInitialization(): Executed after calling the PostConstruct or
 *  				Executed before handling over the object to client.
 *  		
 */

@Component
public class BeanProcessorImpl implements InstantiationAwareBeanPostProcessor, BeanPostProcessor{

	//It comes from BeanPostProcessor. The method can be used to validate injections for a bean.
	@Override
	public Object postProcessBeforeInstantiation(Class<?> beanClass, String beanName) throws BeansException {
		// TODO Auto-generated method stub
		
		//Logic to programmatically create a bean can go here.
		System.out.println(beanClass.getName() + " " + beanName);
//		if(beanName.equals("empDao")){
//		EmpDao dao =new EmpDaoImpl();
//		return dao;}
		
		return null;
				}
	
	//2)
	@Override
	public boolean postProcessAfterInstantiation(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessAfterInstantiation()");
		return true;
	}

	
	
	
	//It comes from BeanPostProcessor
	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
	System.out.println("postProcessAfterInitialization()");
	if(beanName.equals("empDao")){
		EmpDaoImpl dao = (EmpDaoImpl) bean;
		if(dao.getValue()!=10){
			dao.setValue(10);
		}
	}
	return bean;
	}
	//It comes from BeanPostProcessor
	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("postProcessBeforeInitialization()");
		return bean;
	}
	
	
	//3)
	@Override
	public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName)
			throws BeansException {
		// TODO Auto-generated method stub
		
		System.out.println("postProcessProreties");
		return pvs;
	}

	//4) 
	@Override
	public PropertyValues postProcessPropertyValues(PropertyValues pvs, PropertyDescriptor[] pds, Object bean,
			String beanName) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("postProcessProretyValue");
		return pvs;
	}

	
	
	
	
}
