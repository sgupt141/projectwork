package com.cg.web.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.dto.EmpDto;
import com.cg.core.services.EmpService;

// http://localhost:8090/Spring135_MVC_JPA/empService/home.do
@Controller
@RequestMapping("/empService")
public class EmpController {
	
	@Autowired
	private EmpService empService;
	@RequestMapping("/home.do")
	public String getHomePage(){
		return "Home";
	}
	
	@RequestMapping("/login.do")
	public String getLoginPage(){
		
		return "login";
	}
	
	@RequestMapping("/authenticate.do")
	public ModelAndView authenticate(
			@RequestParam("username") String username,
			@RequestParam("password") String password){
		
//		String username = req.getParameter("username");
//		String password = req.getParameter("password");
		String fullName = empService.authenticate(username,password);
		ModelAndView mv = null;
		if(fullName!=null)
		{
			mv= new ModelAndView("MainMenu");
			mv.addObject("fullName", fullName);
		}
		else
		{
			mv= new ModelAndView("login");
			mv.addObject("msg", "Authentication failed, Plz do agian");
		}
		return mv;
		//System.out.println("Username: "+ username+ " password: "+ password);
		//return "MainMenu";
	}
	@RequestMapping("/empList.do")
	public ModelAndView getEmpList(){
		
		List<EmpDto> empList = null;
		try {
			empList = empService.getEmpList();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("empList", empList);
		mv.setViewName("EmpList");
		return mv;
	}
	
	/*
	 * 1) Create a command object in controller
	 * 2) Use and define command object path in jSP.
	 * 3) Populate the command object in the controller.
	 */
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm(){
		
		// create a command object
		EmpDto emp = new EmpDto(0, "Enter Name", 1000);
		ModelAndView mv = new ModelAndView();
		mv.addObject("emp", emp);
		mv.setViewName("EntryForm");
		
		return mv;
	}
	
//	@RequestMapping(value="/submitForm.do", method=RequestMethod.POST)
//	public ModelAndView joinNewEmp(@RequestParam("empNo") int empNo,
//								   @RequestParam("eName") String eName,
//								   @RequestParam("sal") float sal){
//		EmpDto emp = new EmpDto(empNo, eName, sal);
//		try {
//			emp= empService.joinNerEmp(emp);
//		} catch (Exception e) {
//			
//			e.printStackTrace();
//		}
//		ModelAndView mv = new ModelAndView();
//		mv.addObject("emp", emp);
//		mv.setViewName("SuccessInsert");
//		
//		return mv;
//	}
	
	@RequestMapping(value="/submitForm.do", method=RequestMethod.POST)
	public ModelAndView joinNewEmp(@ModelAttribute("emp") EmpDto emp){
		try {
			emp= empService.joinNerEmp(emp);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("emp", emp);
		mv.setViewName("SuccessInsert");
		
		return mv;
	}
	@RequestMapping("/mainMenu.do")
	public String getMainMenu(){
		return "MainMenu";
	}
}
