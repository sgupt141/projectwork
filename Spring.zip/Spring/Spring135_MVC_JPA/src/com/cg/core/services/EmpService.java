package com.cg.core.services;

import java.util.List;

import com.cg.core.dao.EmpDao;
import com.cg.core.dto.EmpDto;
import com.cg.core.exceptions.EmpException;

public interface EmpService {
	
	public String authenticate(String username, String password);
	
	public List<EmpDto> getEmpList() throws EmpException ;
	
	public EmpDto joinNerEmp(EmpDto emp) throws EmpException;
}
