package com.cg.core.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.core.dao.EmpDao;
import com.cg.core.dto.EmpDto;
import com.cg.core.exceptions.EmpException;



/*
 * Transactions:
 * 		Requires-New: Always start a new transaction
 * 		Required: will work in existing transaction but if not existing, creates new.
 * 		Mandatory: Doesn't create new but must work on existing
 * 		Never: Must never work in any transaction
 * 		Supported: Doesn't need the transaction but can propagate
 * 		Not-Supported: Doesn't need the transaction and doesn't work on it.   
 */


@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService{
	
	@Autowired
	public EmpDao dao;
	
	@Override
	public String authenticate(String username, String password){
		if((username.equals("aa")) && (password.equals("bb"))){
			return "Sumit";
		}
		else
		return null;
	}
	
	@Override
	public List<EmpDto> getEmpList() throws EmpException {
		
		return dao.getEmpList();
	}

	@Override
	@Transactional(propagation= Propagation.REQUIRED)
	public EmpDto joinNerEmp(EmpDto emp) throws EmpException {
		
		return dao.insertNewEmp(emp);
	}
}
