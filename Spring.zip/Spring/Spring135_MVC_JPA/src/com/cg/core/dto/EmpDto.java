package com.cg.core.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="emp")
public class EmpDto {
	@Id
	@Column(name="empno")
	private int empId;
	
	@Column(name="ename")
	private String firstName;
	
	@Column(name="sal")
	private float salary;
	
	public EmpDto(int empId, String firstName, float salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.salary = salary;
	}
	public EmpDto() {
		super();
	}
	public int getEmpId() { // empId
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() { // property name= first name
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "EmpDto [empId=" + empId + ", firstName=" + firstName + ", salary=" + salary + "]";
	}
	
}
