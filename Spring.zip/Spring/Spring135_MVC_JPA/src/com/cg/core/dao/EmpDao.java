package com.cg.core.dao;

import java.util.List;

import com.cg.core.dto.EmpDto;
import com.cg.core.exceptions.EmpException;

public interface EmpDao {
	
	public List<EmpDto> getEmpList() throws EmpException;
	
	public EmpDto insertNewEmp(EmpDto emp) throws EmpException;
}
