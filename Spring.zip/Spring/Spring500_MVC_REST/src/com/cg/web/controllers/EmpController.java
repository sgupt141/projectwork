package com.cg.web.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.core.dto.EmpDto;
import com.cg.core.services.EmpService;

// http://localhost:8090/Spring500_MVC_REST/rest/empService/empList
@RestController
@RequestMapping("/empService")
public class EmpController {
	
	@Autowired
	private EmpService empService;
	
	@GetMapping(value="/empList", produces="application/json") // getMapping= requestmapping + get method type
	public List<EmpDto> getEmpList(){
		
		List<EmpDto> empList = null;
		try {
			empList = empService.getEmpList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return empList;
	}
}
