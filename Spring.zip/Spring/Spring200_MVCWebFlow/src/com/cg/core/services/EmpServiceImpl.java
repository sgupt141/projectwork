package com.cg.core.services;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService{
	
	public String authenticate(String username, String password){
		if((username.equals("aa")) && (password.equals("bb"))){
			return "Sumit";
		}
		else
		return null;
	}
}
