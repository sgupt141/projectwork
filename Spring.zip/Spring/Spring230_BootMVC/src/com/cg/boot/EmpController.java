package com.cg.boot;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


//  http://localhost:8082/Spring230_BootMVC/empService/home.do
@Controller
@RequestMapping("/empService")
public class EmpController {
	
	@RequestMapping("/home.do")
	public String getHomePage(){
		return "Home";
	}
}
