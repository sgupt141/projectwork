package com.cg.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.web.dto.QueryDTO;
import com.cg.web.exceptions.CustomException;
import com.cg.web.service.QueryService;

// http://localhost:8090/FortuneForum_46023288/fortuneService/home.do
@Controller
@RequestMapping("/fortuneService") 
public class QueryController {
	
	@Autowired
	QueryService queryService;

	@RequestMapping("/home.do")

	public String getHomePage() {
		return "Home";
	}

	@RequestMapping("/queryDetails.do")
	public ModelAndView getQueryList(@RequestParam("queryId") int queryId) {
		ModelAndView mAndV = null;
		if (queryId < 1) {
			mAndV = new ModelAndView("Home");
			mAndV.addObject("msg", "QueryID cannot be less than 1");
		}
		else
		{
		QueryDTO queryDto = null;
		try {
			queryDto = queryService.getQueryList(queryId);
			if (queryDto != null) {
				mAndV = new ModelAndView();
				mAndV.addObject("queryDto", queryDto);
				mAndV.setViewName("QueryDetails");
			} else {
				mAndV = new ModelAndView("QueryNotFound");
				mAndV.addObject("queryId", queryId);
			}
		} catch (CustomException e) {

			System.out.println(e.getMessage());
		}
		}
		return mAndV;
	}

}
