package com.cg.web.service;

import java.util.List;

import com.cg.web.dto.QueryDTO;
import com.cg.web.exceptions.CustomException;


public interface QueryService 
{
	 public QueryDTO getQueryList(int queryId) throws CustomException; 
}
