package com.cg.web.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.web.dao.QueryDAO;
import com.cg.web.dto.QueryDTO;
import com.cg.web.exceptions.CustomException;

@Service
public class QueryServiceImpl implements QueryService {
	@Autowired
	public QueryDAO querydao;

	@Override
	public QueryDTO getQueryList(int queryId) throws CustomException {
		return querydao.getQueryList(queryId);
	}

}
