package com.cg.web.dao;


import com.cg.web.dto.QueryDTO;
import com.cg.web.exceptions.CustomException;

public interface QueryDAO 
{
	 public QueryDTO getQueryList(int queryId) throws CustomException; 
}
