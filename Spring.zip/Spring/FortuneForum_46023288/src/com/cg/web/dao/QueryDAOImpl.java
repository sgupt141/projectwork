package com.cg.web.dao;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.web.dto.QueryDTO;
import com.cg.web.exceptions.CustomException;
@Repository
public class QueryDAOImpl implements QueryDAO
{   
	@PersistenceContext
	   private EntityManager manager;
	//Method that fetches data matching to queryId
	@Override
	public QueryDTO getQueryList(int queryId) throws CustomException
	{      
		  QueryDTO queryDto =  manager.find(QueryDTO.class, queryId);
		  if(queryDto!=null)
		  return queryDto;
		  else
			  return null;
	}

}
