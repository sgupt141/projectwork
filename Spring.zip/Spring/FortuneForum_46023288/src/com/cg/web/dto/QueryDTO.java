package com.cg.web.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "query_master")
public class QueryDTO {
	@Id
	@Column(name = "QUERY_ID")
	private int queryId;
	@Column(name = "TECHNOLOGY")
	private String technology;
	@Column(name = "QUERY_RAISED_BY")
	private String queryRaisedBy;
	@Column(name = "QUERY")
	private String query;

	public QueryDTO() {
		super();
	}

	public QueryDTO(int queryId, String technology, String queryRaisedBy, String query) {
		super();
		this.queryId = queryId;
		this.technology = technology;
		this.queryRaisedBy = queryRaisedBy;
		this.query = query;
	}

	public int getQueryId() {
		return queryId;
	}

	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}

	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	@Override
	public String toString() {
		return "QueryDTO [queryId=" + queryId + ", technology=" + technology + ", queryRaisedBy=" + queryRaisedBy
				+ ", query=" + query + "]";
	}
}
