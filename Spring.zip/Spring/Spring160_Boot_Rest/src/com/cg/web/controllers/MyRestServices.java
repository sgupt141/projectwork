package com.cg.web.controllers;

import java.net.Authenticator.RequestorType;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.web.boot.dto.Employee;
import com.cg.web.boot.service.EmpService;


//  	http://localhost:8082/emplList
//      http://localhost:8082/newEmp
//      http://localhost:8082/hello
@RestController
public class MyRestServices {
	
	@Autowired
	private EmpService service;
	
	@RequestMapping("/hello")
	public String hello(){
		return "Hello Sumit Gupta";
	}
	
	@RequestMapping(value="/empList", produces="application/json")
	public List<Employee> getEmpList(){
		
		List<Employee> empList = service.getEmpList();
		return empList;
	}
	@RequestMapping(value="/empList", produces="application/json", consumes="application.json", method=RequestMethod.POST)
	public @ResponseBody Employee joinNewEmployee(@RequestBody Employee emp){
		return service.joinNewEmployee(emp);
	}
}
