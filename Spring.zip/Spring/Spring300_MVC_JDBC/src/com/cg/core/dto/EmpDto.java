package com.cg.core.dto;

public class EmpDto {
	
	private int empId;
	private String firstName;
	private float salary;
	public EmpDto(int empId, String firstName, float salary) {
		super();
		this.empId = empId;
		this.firstName = firstName;
		this.salary = salary;
	}
	public EmpDto() {
		super();
	}
	public int getEmpId() { // empId
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getFirstName() { // property name= first name
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "EmpDto [empId=" + empId + ", firstName=" + firstName + ", salary=" + salary + "]";
	}
	
}
