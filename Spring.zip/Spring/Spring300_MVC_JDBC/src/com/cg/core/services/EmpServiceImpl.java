package com.cg.core.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.cg.core.dao.EmpDao;
import com.cg.core.dto.EmpDto;
import com.cg.core.exceptions.EmpException;

@Service
@Scope("singleton")
public class EmpServiceImpl implements EmpService{
	
	@Autowired
	public EmpDao dao;
	
	@Override
	public String authenticate(String username, String password){
		if((username.equals("aa")) && (password.equals("bb"))){
			return "Sumit";
		}
		else
		return null;
	}
	
	@Override
	public List<EmpDto> getEmpList() throws EmpException {
		
		return dao.getEmpList();
	}
}
