package com.cg.eis.pl;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.*;

public class EmployeeTest {

	public static void main(String[] args) 
	{
		Scanner sc =new Scanner(System.in);
		TestSalary valid=new TestSalary();
		System.out.println("Enter number of employees");
		int count = sc.nextInt();
		Employee emp[] =new Service[count];
		for(int i=0;i<count;i++)
		{
		System.out.println("Enter Employee Id");
		int empId = sc.nextInt();
		System.out.println("Enter Employee Name");
		String empName = sc.next();
		System.out.println("Enter Employee Salary");
		float empSal = sc.nextFloat();
		try
		{
			valid.isSalValid(empSal);
			System.out.println("Enter Employee Designation");
			String empDesig =sc.next();
			emp[i]= new Service(empId, empName, empSal, empDesig);
			System.out.println("---------Employee Details-------------\n");
			for(int index=0;i<count;i++)
			{
			     System.out.println(emp[index].toString());	
			}
		}
		catch(EmployeeException e)
		{
			System.out.println(e);
		}
		}
		
		}
	}



