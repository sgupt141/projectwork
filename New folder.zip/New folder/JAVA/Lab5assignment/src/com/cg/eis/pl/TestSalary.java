package com.cg.eis.pl;

import com.cg.eis.exception.EmployeeException;

public class TestSalary {
	void isSalValid(float sal)
	{
		if(sal<3000.0)
			throw new EmployeeException("Salary is less than 3000");
	}
}
