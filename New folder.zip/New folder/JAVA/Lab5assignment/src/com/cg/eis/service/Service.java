
package com.cg.eis.service;
import com.cg.eis.bean.Employee;

interface EmployeeService 
{
   public void calcInsuranceScheme();
}
public class Service extends Employee implements EmployeeService
{
	public Service(int empId, String empName, float empSal, String empDesignation)
	{
		super(empId, empName, empSal, empDesignation);
		calcInsuranceScheme();
	}
    public void calcInsuranceScheme()
    {    
    	
    	if((this.getEmpSal() >5000 && this.getEmpSal()<20000) && this.getEmpDesignation().equalsIgnoreCase("System Associate"))
    	{
    		this.setEmpInsScheme("Scheme A");
    	}
    	else if((this.getEmpSal()>=20000 && this.getEmpSal()<40000) && this.getEmpDesignation().equalsIgnoreCase("Programmer"))
    	{
    		this.setEmpInsScheme("Scheme B");
         }	
    	else if((this.getEmpSal() >=40000) && this.getEmpDesignation().equalsIgnoreCase("Manager"))
    	{
    		this.setEmpInsScheme("Scheme C");
    	}
    	else if ((this.getEmpSal()<5000) && this.getEmpDesignation().equalsIgnoreCase("Clerk"))
    	{
    		this.setEmpInsScheme("No Scheme");
    	}
    	else
    	{
    		this.setEmpInsScheme("No Scheme");
    	}
    }
}

