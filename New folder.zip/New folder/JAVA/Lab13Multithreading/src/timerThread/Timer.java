package timerThread;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Timer implements Runnable{
	
	public void display(){
		int counter = 0;
		while (true) {
			try {
				System.out.println(String.format("%02d", counter));
				Thread.sleep(1000);
				counter++;
				if (counter == 10) {
					System.out.println(String.format("%02d", counter));
					break;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			} 
		}
	}
	
	@Override
	public void run() {
		int count = 0;
		try {
			FileInputStream fis = new FileInputStream("resources/timerCount.txt");
			count = fis.read()-'0';
			System.out.println("Count = "+count);
			fis.close();
			int index=1;
			while(index<=count){
				System.out.println("Timer - "+String.format("%02d", index)+" - starts!");
				display();
				index++;
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
