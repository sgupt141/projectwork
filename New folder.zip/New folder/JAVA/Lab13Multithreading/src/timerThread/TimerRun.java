package timerThread;

public class TimerRun {
	public static void main(String[] args) {
		Timer timer = new Timer();
		Thread timerThread = new Thread(timer);
		timerThread.setName("Timer Thread");
		System.out.println("Thread's Name is = "+timerThread.getName());
		timerThread.start();
	}
}
