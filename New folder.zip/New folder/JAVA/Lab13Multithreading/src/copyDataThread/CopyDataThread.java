package copyDataThread;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class CopyDataThread extends Thread{
	
	public CopyDataThread(){
		super();
	}
	
	public CopyDataThread(String name){
		this.setName(name);
	}
	
	public void run(){
		try {
			FileInputStream fis = new FileInputStream("resources/source.txt");
			FileOutputStream fos = new FileOutputStream("resources/target.txt");
			int i = 0,ch;
			while((ch=fis.read())!=-1){
				i++;
				fos.write(ch);
				System.out.print((char)ch);
				if(i==10){
					i=0;
					System.out.println("\n10 Characters have been written!\nWaiting 5 seconds!");
					Thread.sleep(5000);
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
