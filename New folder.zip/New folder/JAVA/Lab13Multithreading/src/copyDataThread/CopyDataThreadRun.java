package copyDataThread;

public class CopyDataThreadRun {
	public static void main(String[] args) {
		CopyDataThread thread = new CopyDataThread("Copy Thread");
		System.out.println("Threads name is = "+thread.getName());
		thread.start();
	}
}
