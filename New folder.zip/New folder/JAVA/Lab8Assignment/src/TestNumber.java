import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TestNumber {

	public static void main(String[] args) throws IOException {
		FileReader fr =new FileReader("C:\\Users\\SGUPT141\\Desktop\\numbers.txt");
		try
		{
			Scanner sc = new Scanner(fr);
			String string = "";
			while(sc.hasNextLine())
			{
				string = sc.nextLine();
			}
			int i;
			for(i=0;i<string.length()-2;i++)
			{
				String str=string.charAt(i)+"";
				if(i%2==0 )
				{
					int temp = Integer.parseInt(str);
					if(temp%2==0)
						System.out.println(temp);	
				}
			}
			System.out.println(string.substring(20,22));
		}
	  catch(Exception e)
	  {
		  System.out.println("Something went wrong");
	  }
	}
}
