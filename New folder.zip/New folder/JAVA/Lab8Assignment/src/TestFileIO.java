import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TestFileIO {

	public static void main(String[] args) throws IOException 
	{
		FileReader fr =new FileReader("C:\\Users\\SGUPT141\\Desktop\\sumit.txt");
		try
		{
			Scanner sc = new Scanner(fr);
			StringBuffer sf =new StringBuffer();
			while (sc.hasNextLine()) 
				sf.append(sc.nextLine());
			sf.reverse();
			System.out.println(sf);
			PrintWriter pw=new PrintWriter("C:\\Users\\SGUPT141\\Desktop\\sumitgupta.txt");
			pw.write(sf.toString());
			pw.flush();		
		}
	  catch(Exception e)
	  {
		  System.out.println("Something went wrong");
	  }
		
	}

}
