package com.cg.stream;

public class EmployeeMain {

	public static void main(String[] args) {
		EmployeeService emp=new EmployeeService();
		System.out.println("Total Salary= "+emp.empSalCal());
		System.out.println("-----");
		emp.countEmployees();
		System.out.println("-----");
		emp.nameDurationEmp();
		System.out.println("-----");
		emp.rvf();
		System.out.println("-----");
		System.out.println("Maximum employees in a department\n");
		emp.maxEmployeeDept();
		
//		System.out.println("-----");
//		emp.empCountCal();
//		System.out.println("-----");
//		emp.nameAndDurationEmp();
//		System.out.println("-----");
//		emp.empWithoutDept();
//		System.out.println("-----");
//		emp.maxEmployeeDept();
	}

}
