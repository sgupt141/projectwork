package com.cg.stream;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.stream.Stream;

public class EmployeeRepository {

		static private ArrayList<Employee> arrList = new ArrayList<>();
		static
		{
		EmployeeService empSal=new EmployeeService();
		Department obj=new Department();
		obj.setDeptId(121);
		obj.setDeptName("CSE");
		obj.setManagerId(222);
		Department obj1=new Department();
		obj1.setDeptId(131);
		obj1.setDeptName("IT");
		obj1.setManagerId(111);
		Department obj2=new Department();
		obj2.setDeptId(141);
		obj2.setDeptName("CSE");
		obj2.setManagerId(333);
		Employee emp1=new Employee(12,"Sumit","Gupta","sumit@gmail.com","98569856985",
				LocalDate.of(2018,8,5),"Programmer",6000,121,obj);
		Employee emp2=new Employee(13,"Yash","Bhatia","yash@gmail.com","98515455555",
				LocalDate.of(2019,5,6),"Programmer",8888,101,obj1);
		Employee emp3=new Employee(12,"Amman","Ahamad","amman@gmail.com","98569884885",
				LocalDate.of(2017,6,5),"Programmer",9000,777,obj2);
		arrList.add(emp1);
		arrList.add(emp2);
		arrList.add(emp3);
		//System.out.println(arrList);
		}
		public static ArrayList<Employee> getArrList() {
			return arrList;
		}
		public static void setArrList(ArrayList<Employee> arrList) {
			EmployeeRepository.arrList = arrList;
		}
}
