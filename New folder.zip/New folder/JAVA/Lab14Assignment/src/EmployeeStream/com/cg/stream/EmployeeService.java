package com.cg.stream;

import java.net.StandardSocketOptions;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.Stream;

import org.omg.Messaging.SyncScopeHelper;

public class EmployeeService {
	
	ArrayList<Integer> idList = new ArrayList<>();
	ArrayList<String> nameList = new ArrayList<>();
	ArrayList<Employee> empList = EmployeeRepository.getArrList();
	EmployeeService()
	{
		nameList.clear();
		idList.clear();
	}
	double empSalCal()
	{
		Double sum = empList.stream().mapToDouble(x->x.getEmpSal()).sum();
		return sum;
	}
	void countEmployees()
	{
		empList.stream().collect(Collectors.groupingBy
				(emp->emp.getDept().getDeptName(),Collectors.counting())).
				forEach((k,v)->System.out.println(k + "  "+ v));
	}
	void rvf()
	{
		empList.stream().forEach(emp->{
			 if(emp.getHireDate().getDayOfWeek().getValue()==1){
			System.out.println("Name : "+emp.getEmpFirstName()+ " Day of week Joined: " +emp.getHireDate().getDayOfWeek());
			 }
		});
	}
	void nameDurationEmp()
	{
		empList.stream().forEach(emp->{
			System.out.println("Name : "+emp.getEmpFirstName()+ " --->  Days worked: " 
		+Period.between(emp.getHireDate(),LocalDate.now()).getDays());
			
		});
	}
	void maxEmployeeDept()
	{
		Map<Object, Long> empMap=	empList.stream().collect(Collectors.groupingBy
				(emp->emp.getDept().getDeptName(),Collectors.counting()));
		String dept=(String)empMap.entrySet().stream().max(Map.Entry.comparingByValue()).get().getKey();
		System.out.println(dept);
	}
	
	
//	void empCountCal()
//	{
//		HashMap<String,Integer> map=new HashMap<String,Integer>();
//		empList.stream().collect(Collectors.groupingBy(emp->emp.getDept().getDeptName(),Collectors.counting())).
//				forEach((k,v)->System.out.println(k + "  "+ v));
//	} 
//	void nameAndDurationEmp()
//	{
//		ArrayList<String> empList = new ArrayList<>();
//		for (int i=0;i<EmployeeRepository.getArrList().size();i++)  
//		{
//			Employee emp=(Employee)EmployeeRepository.getArrList().get(i);
//			String empName=emp.getEmpFirstName();
//			Stream<String> stream = Stream.of(empName);
//			stream.forEach(name1->System.out.println(name1));
//			String name =emp.getEmpFirstName();
//			empList.add(name);
//			LocalDate date=emp.getHireDate();
//			LocalDate curDate= LocalDate.now();
//			Period period = date.until(curDate);
//			System.out.println("Days:- "+period.getDays()+"\nMonths:- "
//					+period.getMonths()+"\nYears:- "+period.getYears());
//		}
//	}
//	void empWithoutDept()
//	{
//		
//		empList.stream().filter(x-> x.getDept()==null).forEach(System.out::println);
//		
//	}
//	void maxEmployeeDept()
//	{
//		ArrayList<Integer> deptList = new ArrayList<>();
//		int count=0;
//		int id=0;
//		int maxDept=0;
//		Department dept=null;
//		for (int i=0;i<EmployeeRepository.getArrList().size();i++)  
//		{
//			count=0;
//			Employee emp=(Employee)EmployeeRepository.getArrList().get(i);
//			id=emp.getDept().getDeptId();
//			deptList.add(id);
//			count=(int)deptList.stream().count();
//			if(count>maxDept)
//			{
//				dept=emp.getDept();
//				maxDept=count;
//			}
//			deptList.clear();
//			
//		}
//		System.out.println("Number of Employee in each department:\n"+dept.getDeptName());
//	}
	
}
