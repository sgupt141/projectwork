package com.cg.stream;

import java.sql.Date;
import java.time.LocalDate;

public class Employee {

	private int empId;
	private String empFirstName;
	private String empLastName;
	private String empNumber;
	private String empEmail;
	private LocalDate hireDate;
	private String empDesidn;
	private int empSal;
	private int managerID;
	private Department dept;
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empFirstName=" + empFirstName + ", empLastName=" + empLastName
				+ ", empNumber=" + empNumber + ", empEmail=" + empEmail + ", hireDate=" + hireDate + ", empDesidn="
				+ empDesidn + ", empSal=" + empSal + ", managerID=" + managerID + ", dept=" + dept + "]";
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public String getEmpNumber() {
		return empNumber;
	}
	public void setEmpNumber(String empNumber) {
		this.empNumber = empNumber;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	public LocalDate getHireDate() {
		return hireDate;
	}
	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}
	public String getEmpDesidn() {
		return empDesidn;
	}
	public void setEmpDesidn(String empDesidn) {
		this.empDesidn = empDesidn;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	public int getManagerID() {
		return managerID;
	}
	public void setManagerID(int managerID) {
		this.managerID = managerID;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public Employee(int empId, String empFirstName, String empLastName, String empNumber, String empEmail,
			LocalDate hireDate, String empDesidn, int empSal, int managerID, Department dept) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empNumber = empNumber;
		this.empEmail = empEmail;
		this.hireDate = hireDate;
		this.empDesidn = empDesidn;
		this.empSal = empSal;
		this.managerID = managerID;
		this.dept = dept;
	}
	
}
