import java.util.Scanner;
import java.util.function.Consumer;
import java.util.function.Supplier;

interface Display
{
	void display(String str);
}
public class TestClass
{
		public void displayStr(String str)
		{
			System.out.println("String= "+str);
		}
}

