
public class MainClass {

	public static void main(String[] args) {
		TestClass test =new TestClass();
		Display data=test::displayStr;
		data.display("Sumit");
	}

}
