@FunctionalInterface
public interface ValidateInterface {
	boolean test(String username, String password);
}
