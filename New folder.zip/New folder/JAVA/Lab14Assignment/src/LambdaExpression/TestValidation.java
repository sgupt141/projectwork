import java.util.Scanner;
import java.util.function.BiPredicate;
import java.util.function.Predicate;
import java.util.regex.Pattern;

public class TestValidation {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter username:\n");
		String userName=scan.next();
		System.out.println("Enter password:\n");
		String password=scan.next();
		BiPredicate<String,String> pre = (name,pass)->{
			String namePattern="^[a-z0-9_-]{3,15}$";
			String passwordPattern ="((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
			if(Pattern.matches(namePattern,name) && Pattern.matches(passwordPattern, pass))
				return true;
			else
				return false;
			
		};
		System.out.println(pre.test(userName, password));
	}

}
