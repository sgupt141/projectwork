import java.util.Scanner;

public class FactorialDemo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter number: \n");
		int num=scan.nextInt();
		FactorialInterface factorial = (x) -> {
            int result = 1;
            for (int i = 1; i <= x; i++)
            result = i * result;
            return result;
        };
		System.out.println(factorial.fact(num));

	}

}
