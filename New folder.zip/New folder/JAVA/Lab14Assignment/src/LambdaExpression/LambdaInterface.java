@FunctionalInterface
public interface LambdaInterface {
	
	long fun(int x,int y); 
	
}
