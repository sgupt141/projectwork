@FunctionalInterface
public interface FactorialInterface {
	int fact(int num);
}
