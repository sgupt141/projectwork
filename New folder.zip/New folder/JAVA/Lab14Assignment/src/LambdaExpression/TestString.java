import java.util.Scanner;

public class TestString {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter String:\n");
		String str=scan.next();
		
		StringInterface strInter =(input)->{
			String modifyString="";
			for(int i=0;i<str.length();i++)
			{
				char ch=input.charAt(i);
				modifyString = modifyString + ch + " ";
			}
			return modifyString;
		};
		System.out.println(strInter.fun(str));
	}

}
