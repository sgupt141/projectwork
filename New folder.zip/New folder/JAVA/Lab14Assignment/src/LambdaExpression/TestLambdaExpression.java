import java.util.Scanner;

public class TestLambdaExpression {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 1st number: \n");
		int num1=scan.nextInt();
		System.out.println("Enter 2st number: \n");

		int num2 =scan.nextInt();
		LambdaInterface lam =(x,y)-> {
			
			return (long)Math.pow(x,y);
		};
		System.out.println(lam.fun(num1,num2));
	}
}
