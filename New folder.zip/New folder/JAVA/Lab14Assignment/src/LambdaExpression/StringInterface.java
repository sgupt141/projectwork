
public interface StringInterface {
	String fun(String str);
}
