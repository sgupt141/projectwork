package com.cg.mps.dto;

public class Mobile {
	
	private int mobileid,price;
	private String name,quantity;
	
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public Mobile(int mobileid, String name, int price, String quantity) {
		super();
		setMobileid(mobileid);
		setPrice(price);
		setName(name);
		setQuantity(quantity);
	}
	
}
