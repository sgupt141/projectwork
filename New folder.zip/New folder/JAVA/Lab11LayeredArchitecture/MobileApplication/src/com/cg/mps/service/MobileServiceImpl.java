package com.cg.mps.service;


import com.cg.mps.dao.MobileDAOImpl;

public class MobileServiceImpl extends MobileDAOImpl {
	MobileDAOImpl mob=new MobileDAOImpl();
	
}
