package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

import com.cg.mps.dto.Purchase;
import com.cg.mps.exception.LowQuantityException;

public class PurchaseDAOImpl implements PurchaseDAO{

	@Override
	public boolean addPurchase(Purchase pur) throws SQLException {
		//CREATE TABLE purchasedetails(purchaseid NUMBER, cname vARCHAR2(20), mailid VARCHAR2(30),
		//phoneno VARCHAR2(20), purchasedate DATE, mobileid references mobiles(mobileid));		
		Connection connection =null;
		Savepoint savepoint = null;
		try{
			connection = DBConnection.getInstance();
			connection.setAutoCommit(false);
			savepoint = connection.setSavepoint();
			
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select quantity from mobiles where mobileid="+pur.getMobileID());
			int quantity=0;
			if(rs.next()){
				quantity = rs.getInt(1);
			}
			if(quantity > 0){
				PreparedStatement ps = connection.prepareStatement(
						"insert into purchasedetails values(?,?,?,?,?,?)");
				ps.setInt(1, pur.getPurchaseid());
				ps.setString(2, pur.getCname());
				ps.setString(3, pur.getMailid());
				ps.setString(4, pur.getPhoneno());
				ps.setDate(5, pur.getPurchasedate());
				ps.setInt(6, pur.getMobileID());
				ps.execute();
				
				int altered = st.executeUpdate("update mobiles set quantity = "+(quantity-1)+" where mobileid="+pur.getMobileID());
				if(altered == 1)
					return true;
			}else
				throw new LowQuantityException();
			
		} catch (ClassNotFoundException | LowQuantityException| SQLException e) {
			e.printStackTrace();
			connection.rollback(savepoint);
		}finally {
			connection.setAutoCommit(true);
		}
		return false;
		
	}

}
