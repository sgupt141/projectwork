package com.cg.mps.dto;

import java.sql.Date;
import java.time.LocalDate;


public class Purchase {
	private int purchaseid;
	private String cname,mailid,phoneno;
	private Date purchasedate;
	private int mobileid;
	public int getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(int purchaseid) {
		this.purchaseid = purchaseid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getMailid() {
		return mailid;
	}
	public void setMailid(String mailid) {
		this.mailid = mailid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}
	public int getMobileID() {
		return mobileid;
	}
	public void setMobileID(int mobileid) {
		this.mobileid = mobileid;
	}
	public Purchase(int purchaseid, String cname, String mailid, String phoneno, Date purchasedate,
			int mobileid) {
		super();
		setCname(cname);
		setMailid(mailid);
		setPhoneno(phoneno);
		setPurchasedate(purchasedate);
		setMobileID(mobileid);
	}
	
}
