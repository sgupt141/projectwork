package com.cg.mps.dao;

import java.sql.SQLException;

import com.cg.mps.dto.Purchase;
 

public interface PurchaseDAO {
	boolean addPurchase(Purchase pur) throws SQLException;
}
