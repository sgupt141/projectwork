package com.cg.mps.dao;
import java.io.FileReader;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;
import java.sql.Connection;

public class DBConnection {
	private static Connection con = null;
	private static DBConnection dbc = new DBConnection();
	private DBConnection(){}
	public static Connection getInstance() throws ClassNotFoundException, SQLException{
		if(con == null)
			con=dbc.getConnection();
		return con;
	}
	public Connection getConnection() throws ClassNotFoundException, SQLException{
		try(FileReader fr = new FileReader("resource/oracle.properties")){
			Properties prop = new Properties();
			prop.load(fr);
			con = DriverManager.getConnection(prop.getProperty("jdbc.url"),prop.getProperty("jdbc.username")
					,prop.getProperty("jdbc.password"));
		}catch(Exception e){}
		return con;
	}
}
