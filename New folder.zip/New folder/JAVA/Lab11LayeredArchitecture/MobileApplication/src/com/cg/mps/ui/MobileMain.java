package com.cg.mps.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.mps.dao.DBConnection;
import com.cg.mps.service.MobileServiceImpl;

public class MobileMain {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		MobileServiceImpl ref=new MobileServiceImpl();
		DBConnection.getInstance();
		Scanner sc=new Scanner(System.in);
		do
		{
			System.out.println("Choose only one option: \n"+
					"1. Add customer and purchase details\n"+
					"2. Update mobile Quantity details\n"+
					"3. Viwe all details of mobiles in shop\n"+
					"4. Delete a detail bases on mobile ID\n"+
					"5. Display details bases on price range\n"+
					"6. Display details based on name\n"+
					"7. Exit\n");
			int ch=sc.nextInt();
			switch(ch)
			{
			case 1: System.out.println("Enter costumer name: \n");
					String name = sc.next();
					System.out.println("Enter costumer phone number: \n");
					String phone = sc.next();
					System.out.println("Enter costumer address: \n");
					String address = sc.next();
					System.out.println("Enter costumer email: \n");
					String email = sc.next();
			}
		}while(true);
		

	}

}
