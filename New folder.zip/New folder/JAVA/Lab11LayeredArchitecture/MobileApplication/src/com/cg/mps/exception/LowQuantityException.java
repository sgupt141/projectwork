package com.cg.mps.exception;

public class LowQuantityException extends Exception{

}
