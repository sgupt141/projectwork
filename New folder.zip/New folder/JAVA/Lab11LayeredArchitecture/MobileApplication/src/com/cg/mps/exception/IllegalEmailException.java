package com.cg.mps.exception;

public class IllegalEmailException extends Exception{

}
