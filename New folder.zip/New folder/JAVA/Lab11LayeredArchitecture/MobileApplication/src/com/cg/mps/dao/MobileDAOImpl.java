package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.mps.dto.Mobile;


public class MobileDAOImpl implements MobileDAO{

	@Override
	public ArrayList<Mobile> availableMobiles() throws SQLException {
		ArrayList<Mobile> result = new ArrayList<Mobile>();
		Connection connection =null;
		Savepoint savepoint = null;
		try {
			connection = DBConnection.getInstance();
			connection.setAutoCommit(false);
			savepoint = connection.setSavepoint("sp1");
			
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select mobileid,name,price,quantity from mobiles");
			while(rs.next()){
				result.add(new Mobile(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4)));
			}
			connection.releaseSavepoint(savepoint);
		} catch (ClassNotFoundException | SQLException e) {
			connection.rollback(savepoint);
		}finally {
			connection.setAutoCommit(true);
		}
		return result;
	}

	@Override
	public boolean deleteMobile(int id) throws SQLException {
		Connection connection =null;
		Savepoint savepoint = null;
		try{
			connection = DBConnection.getInstance();
			connection.setAutoCommit(false);
			savepoint = connection.setSavepoint();
			
			Statement st = connection.createStatement();
			int rows = st.executeUpdate("delete from mobiles where mobileid="+id);
			if(rows == 1){
				return true;
			}
			return false;
		} catch (ClassNotFoundException | SQLException e) {
			connection.rollback(savepoint);
		}finally {
			connection.setAutoCommit(true);
		}
		return false;
	}

	@Override
	public ArrayList<Mobile> mobilesInRange(int start, int end) throws SQLException {
		ArrayList<Mobile> result = new ArrayList<Mobile>();
		Connection connection =null;
		Savepoint savepoint = null;
		try {
			connection = DBConnection.getInstance();
			connection.setAutoCommit(false);
			savepoint = connection.setSavepoint("sp1");
			
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("select mobileid,name,price,quantity from mobiles "
					+ "where price between "+start+" and "+end);
			while(rs.next()){
				result.add(new Mobile(rs.getInt(1),rs.getString(2),rs.getInt(3),rs.getString(4)));
			}
			connection.releaseSavepoint(savepoint);
		} catch (ClassNotFoundException | SQLException e) {
			connection.rollback(savepoint);
		}finally {
			connection.setAutoCommit(true);
		}
		return result;
	}

}
