package com.cg.mps.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.mps.dto.Mobile;

public interface MobileDAO {
	
	ArrayList<Mobile> availableMobiles() throws SQLException;
	boolean deleteMobile(int id) throws SQLException;
	ArrayList<Mobile> mobilesInRange(int start,int end) throws SQLException;
	
}
