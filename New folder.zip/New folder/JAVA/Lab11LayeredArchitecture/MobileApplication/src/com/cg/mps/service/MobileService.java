package com.cg.mps.service;

public class MobileService {
	
}
