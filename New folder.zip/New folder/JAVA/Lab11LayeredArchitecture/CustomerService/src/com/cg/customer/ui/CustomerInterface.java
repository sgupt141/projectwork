package com.cg.customer.ui;
import java.util.ArrayList;
import java.util.Map.Entry;
import java.util.stream.Stream;
import java.util.Scanner;

import com.cg.customException.CustomException;
import com.cg.customer.dao.CustomerDaoImpl;
import com.cg.customer.dao.OracleConnection;
import com.cg.customer.dao.StaticDb;
import com.cg.customer.dto.CustomerDTO;
import com.cg.customer.service.CustomerServiceImpl;

public class CustomerInterface {

	public static void main(String[] args) {
		//CustomerDaoImpl ref=new CustomerDaoImpl();
		CustomerServiceImpl ref= new CustomerServiceImpl();
		for(Entry<Integer,CustomerDTO> entry : StaticDb.customerList.entrySet())  
            System.out.println("Id = " + entry.getKey() + 
                             ", " + entry.getValue());
		OracleConnection.getInstance();
		Scanner scan=new Scanner(System.in);
		do{
			System.out.println("Choose only one option: \n"+
					"1. Add new detail\n"+
					"2. Delete details based on ID\n"+
					"3. Delete all details\n"+
					"4. Modify details\n"+
					"5. Display details\n"+
					"6. Display details bases on ID\n"+
					"7. Display details based on name\n"+
					"8. Exit\n");
			int ch=scan.nextInt();
			switch(ch)
			{
			case 1: System.out.println("Enter costumer id: \n");
					int id = scan.nextInt();
					System.out.println("Enter costumer name: \n");
					String name = scan.next();
					System.out.println("Enter costumer phone number: \n");
					String phone = scan.next();
					System.out.println("Enter costumer address: \n");
					String address = scan.next();
					System.out.println("Enter costumer email: \n");
					String email = scan.next();
					CustomerDTO custNew= new 
							CustomerDTO(name,phone,address,email);
					try
					{
						System.out.println(ref.addDetail(id,custNew));
					}
					catch(CustomException e)
					{
						System.out.println(e);
					}
					//System.out.println(ref.addDetail(id,custNew));
					break;
			case 2: System.out.println("Enter costumer id: \n");
					int id1 = scan.nextInt();
					try
					{
						System.out.println(ref.deleteDetail(id1));
					}
					catch(CustomException e)
					{
						System.out.println(e);
					}
					break;
			case 3: System.out.println(ref.deleteAllDetail());
					break;
			case 4: System.out.println("Enter costumer id: \n");
					int id3 = scan.nextInt();
					
					break;
			case 5:  System.out.println(ref.displayDetail());
//					for (int i=0;i<StaticDb.arrayList.size();i++)  
//					{
//						CustomerDTO cust=(CustomerDTO)temp.get(i);
//						Stream.of(cust).filter(x-> cust.getCusName().length()>4).forEach(str->System.out.println(str));
//					}
					break;
			case 6: System.out.println("Enter costumer id: \n");
					int id2 = scan.nextInt();
					System.out.println(ref.displayDetailOnId(id2));
					break;
			case 7: System.out.println("Enter costumer name: \n");
					String name1 = scan.next();
					System.out.println(ref.displayDetailOnName(name1));
					break;
			
			case 8: System.exit(0);
					break;
			}

		}while(true);

	}

}
