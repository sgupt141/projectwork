package com.cg.customer.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.bean.NameComponent;
import com.cg.customException.CustomException;
import com.cg.customer.dao.CustomerDao;
import com.cg.customer.dao.CustomerDaoImpl;
import com.cg.customer.dto.CustomerDTO;

public class CustomerServiceImpl implements CustomerDao {
	CustomerDaoImpl ref1 =new CustomerDaoImpl();
	@Override
	public CustomerDTO addDetail(int id, CustomerDTO customer) {
		String name= customer.getCusName();
		String email= customer.getCusEmail();
		String phone= customer.getCusPhone();
		String address= customer.getCusAddress();
		
		NameComponent valid=new NameComponent();
		boolean checkName=valid.isNameValid(name);
		if(checkName==false){
			System.out.println("Name is not valid\n");
			throw new CustomException(name);
		}
		boolean checkId = valid.isIdValid(id);
		if(checkId==false){
			System.out.println("Id is not valid\n");
			throw new CustomException("message");
		}
		boolean checkemail = valid.isEmailValid(email);
		if(checkemail==false){
			System.out.println("Email is not valid\n");
			throw new CustomException(email);
		}
		boolean checkPhone = valid.isPhoneValid(phone);
		if(checkPhone==false){
			System.out.println("Phone no is not valid\n");
			throw new CustomException(phone);
		}
		boolean checkAddress = valid.isAddressValid(address);
		if(checkAddress==false){
			System.out.println("Address is not valid\n");
			throw new CustomException(address);
		}
		//if(checkName && checkId &&  checkemail && checkPhone && checkAddress)
		if(checkName && checkId && checkemail && checkPhone && checkAddress)
			return ref1.addDetail(id,customer);
		else
			throw new CustomException("Message");
	}

	@Override
	public String deleteDetail(int custId) {
		return ref1.deleteDetail(custId);
	}

	@Override
	public String deleteAllDetail() {
		return ref1.deleteAllDetail();
	}

	@Override
	public HashMap<Integer, CustomerDTO> modifyDetail(int custId, CustomerDTO customer) {
		
		return ref1.modifyDetail(custId, customer);
	}

	@Override
	public HashMap<Integer,CustomerDTO> displayDetail() {
		return ref1.displayDetail();
	
		
	}

	@Override
	public HashMap<Integer,CustomerDTO> displayDetailOnName(String name) {

		return ref1.displayDetailOnName(name);
	}

	@Override
	public HashMap<Integer,CustomerDTO> displayDetailOnId(int custId) {
		
		return ref1.displayDetailOnId(custId);
	}



}
