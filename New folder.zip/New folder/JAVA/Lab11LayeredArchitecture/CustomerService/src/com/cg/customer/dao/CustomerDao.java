package com.cg.customer.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.customer.dto.CustomerDTO;

public interface CustomerDao {
	public CustomerDTO addDetail(int id,CustomerDTO customer);
	public String deleteDetail(int custId);
	public String deleteAllDetail();
	public HashMap<Integer, CustomerDTO> modifyDetail(int custId, CustomerDTO customer);
	public HashMap<Integer, CustomerDTO> displayDetail();
	public HashMap<Integer, CustomerDTO> displayDetailOnName(String name);
	public HashMap<Integer, CustomerDTO> displayDetailOnId(int custId);
	
	
}
