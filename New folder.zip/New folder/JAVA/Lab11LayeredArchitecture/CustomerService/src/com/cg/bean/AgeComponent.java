package com.cg.bean;

import com.cg.customException.CustomException;

public class AgeComponent {
	public boolean isValidAge(int age)
	{
		if(age>0 && age<70)
			return true;
		else
			throw new CustomException("12");
	}
	public boolean isValidName(String name)
	{
		if(name.equalsIgnoreCase("Sumit"))
			return true;
		else
			throw new CustomException(name);
	}

}
