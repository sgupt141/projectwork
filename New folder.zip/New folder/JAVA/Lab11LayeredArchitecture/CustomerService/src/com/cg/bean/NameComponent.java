package com.cg.bean;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.customException.CustomException;
import com.cg.customer.dto.CustomerDTO;

public class NameComponent 
{
	public boolean isNameValid(String cust)
	{
		Pattern pattern = Pattern .compile("^[A-Z][a-z]{2,20}");
		Matcher match= pattern.matcher(cust);
		if(match.find())
			return true;
		else
			return false;
	}
	public boolean isEmailValid(String cust)
	{
		Pattern pattern = Pattern .compile("^[\\w-\\+]+(\\.[\\w]+)*@[\\w-]+(\\.[\\w]+)*(\\.[a-z]{2,})$");
		Matcher match= pattern.matcher(cust);
		if(match.find())
			return true;
		else
			return false;
	}
	public boolean isIdValid(int id)
	{
		Pattern pattern = Pattern .compile("^{1,200}");
		Matcher match= pattern.matcher(String.valueOf(id));
		if(match.find())
			return true;
		else
			return false;
	}
	public boolean isPhoneValid(String cust)
	{
		Pattern pattern = Pattern .compile("(0/91)?[7-9][0-9]{9}");
		Matcher match= pattern.matcher(cust);
		if(match.find())
			return true;
		else
			return false;
	}
	public boolean isAddressValid(String cust)
	{
		//Pattern pattern = Pattern .compile("\\d+\\s+([a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+)");
		Pattern pattern = Pattern .compile("^[A-Z][a-z]{2,20}");
		Matcher match= pattern.matcher(cust);
		if(match.find())
			return true;
		else
			return false;
	}
}
