package com.cg.customer.dao;
import java.util.Scanner;
import java.util.Map.Entry;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.customException.CustomException;
import com.cg.customer.dto.CustomerDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;

public class CustomerDaoImpl implements CustomerDao{
	Logger log=Logger.getRootLogger();
	Connection con=null;
	PreparedStatement ps=null;
	
	HashMap<Integer,CustomerDTO> arrMap = new HashMap<>();
	public CustomerDaoImpl()
	{ 
		con =OracleConnection.getConnection();
		PropertyConfigurator.configure("resource/customerlog.properties");
		
	}
	@Override
	public CustomerDTO addDetail(int id, CustomerDTO customer) {
		
		String insertQuery="insert into employee values(?,?,?,?,?)";
		try
		{
		ps =con.prepareStatement(insertQuery);
		ps.setInt(1,id);
		ps.setString(2,customer.getCusName());
		ps.setString(3,customer.getCusPhone());
		ps.setString(4,customer.getCusAddress());
		ps.setString(5,customer.getCusEmail());
		ps.executeUpdate();
		log.info("Customer details added");
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		return customer;
	}
	@Override
	public String deleteDetail(int inputId) {
		try
		{
			ps =con.prepareStatement("Delete from employee where id=?");
			ps.setInt(1, inputId);
			ps.executeUpdate();
			log.info("Customer details Deleted");
		}
		catch( SQLException e)
			{
				e.printStackTrace();
			}
		return "Deleted";
	}

	@Override
	public String deleteAllDetail() {
		try{
			ps =con.prepareStatement("Delete from employee");
			ps.executeUpdate();
			log.info("Customer all details Deleted");
		}
		catch( SQLException e)
		{
			e.printStackTrace();
		}
		return "Delete";
	}

	@Override
	public HashMap<Integer, CustomerDTO> modifyDetail(int inputId, CustomerDTO customer) {
		CustomerDTO obj=new CustomerDTO();
		arrMap.clear();
		try{
			PreparedStatement ps=con.prepareStatement("Update Employee set empname=?,phonenumber=?,address=?,email=? where empId=?");
			ps.setInt(1,inputId);
			ps.setString(2,customer.getCusName());
			ps.setString(3,customer.getCusPhone());
			ps.setString(4,customer.getCusAddress());
			ps.setString(5,customer.getCusPhone());
			ps.executeUpdate();
			log.info("Customer all details Modified\n");
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		return arrMap;
	}

	@Override
	public HashMap<Integer,CustomerDTO> displayDetail() {
		CustomerDTO obj=new CustomerDTO();
		arrMap.clear();
		try{
			Statement stmt=con.createStatement();
			ResultSet status=stmt.executeQuery("select * from Employee");
			while(status.next())
			{
				int id= status.getInt(1);
				obj.setCusName(status.getString(2));
				obj.setCusPhone(status.getString(3));
				obj.setCusAddress(status.getString(4));
				obj.setCusEmail(status.getString(5));
				arrMap.put(id,obj);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return arrMap;
	}

	@Override
	public HashMap<Integer,CustomerDTO> displayDetailOnName(String inputName) {
		CustomerDTO obj=new CustomerDTO();
		arrMap.clear();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from Employee where empname=?");
			stmt.setString(1, inputName);
			ResultSet status=stmt.executeQuery();
			while(status.next())
			{
				int id= status.getInt(1);
				obj.setCusName(status.getString(2));
				obj.setCusPhone(status.getString(3));
				obj.setCusAddress(status.getString(4));
				obj.setCusEmail(status.getString(5));
				arrMap.put(id,obj);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return arrMap;
	}

	@Override
	public HashMap<Integer,CustomerDTO> displayDetailOnId(int inputId) {
		CustomerDTO obj=new CustomerDTO();
		arrMap.clear();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from Employee where empId=?");
			stmt.setInt(1, inputId);
			ResultSet status=stmt.executeQuery();
			while(status.next())
			{
				int id= status.getInt(1);
				obj.setCusName(status.getString(2));
				obj.setCusPhone(status.getString(3));
				obj.setCusAddress(status.getString(4));
				obj.setCusEmail(status.getString(5));
				arrMap.put(id,obj);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		
			}
		return arrMap;
	}
}
