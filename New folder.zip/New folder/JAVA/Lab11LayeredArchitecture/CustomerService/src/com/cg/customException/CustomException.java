package com.cg.customException;

public class CustomException extends RuntimeException{
	public CustomException(String cust)
	{
		super(cust);
	}
}
