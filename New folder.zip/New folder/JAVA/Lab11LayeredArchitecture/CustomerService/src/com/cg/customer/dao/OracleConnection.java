package com.cg.customer.dao;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Enumeration;
import java.util.Properties;

public class OracleConnection 
{
	private static OracleConnection oracleCon=null;
	
	private OracleConnection()
	{
	}
	public static OracleConnection getInstance()
	{
		if(oracleCon==null)
			oracleCon=new OracleConnection();
		return oracleCon;
	}
	public static Connection getConnection()
	{
		String url;
		String user;
		String password;
		Connection con=null;
		try
		{
			FileReader fr = new FileReader("resource//oracle.properties");
			Properties prop=new Properties();
			prop.load(fr);
			
			Enumeration en=prop.keys();
			String urlkey=(String)en.nextElement();
			url=prop.getProperty(urlkey);
			String userkey=(String)en.nextElement();
			user=prop.getProperty(userkey);
			String passwordkey=(String)en.nextElement();
			password=prop.getProperty(passwordkey);
			try
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con =DriverManager.getConnection(url,user,password);
				
			}
			catch(ClassNotFoundException e)
			{
				e.printStackTrace();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return  con;
	}
}
