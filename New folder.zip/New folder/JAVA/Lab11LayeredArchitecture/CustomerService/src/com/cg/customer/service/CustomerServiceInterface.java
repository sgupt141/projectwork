package com.cg.customer.service;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.customer.dto.CustomerDTO;

public interface CustomerServiceInterface {
	public String addDetail(int id,CustomerDTO customer);
	public String deleteDetail(int custId);
	public String deleteAllDetail();
	public String modifyDetail(int custId, CustomerDTO customer);
	public HashMap<Integer,CustomerDTO> displayDetail();
	public ArrayList<CustomerDTO> displayDetailOnName(String name);
	public String displayDetailOnId(int custId);
}
