package com.cg.customer.dto;

public class CustomerDTO{
	private int cusId;
	private String cusName;
	private String cusPhone;
	private String cusAddress;
	private String cusEmail;
	public CustomerDTO(){}
	public CustomerDTO(String cusName, String cusPhone, 
			String cusAddress, String cusEmail) 
	{
		super();
		this.cusName = cusName;
		this.cusPhone = cusPhone;
		this.cusAddress = cusAddress;
		this.cusEmail = cusEmail;
	}
	@Override
	public String toString() {
		return "CustomerDTO: " + "[cusName=" + cusName +
				", cusPhone=" + cusPhone + ", cusAddress="
				+ cusAddress + ", cusEmail=" + cusEmail + "]";
	}
	
	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public String getCusPhone() {
		return cusPhone;
	}
	public void setCusPhone(String cusPhone) {
		this.cusPhone = cusPhone;
	}
	public String getCusAddress() {
		return cusAddress;
	}
	public void setCusAddress(String cusAddress) {
		this.cusAddress = cusAddress;
	}
	public String getCusEmail() {
		return cusEmail;
	}
	public void setCusEmail(String cusEmail) {
		this.cusEmail = cusEmail;
	}
	
}
