package com.cg.customer.dao;
import java.util.ArrayList;
import java.util.HashMap;

import com.cg.customer.dto.*;
public class StaticDb {
	
	public static HashMap<Integer,CustomerDTO> customerList=new HashMap<>();
	public static ArrayList<CustomerDTO> arrayList=new ArrayList<>();
	static
	{
		int Id1=121,Id2=131;
		customerList.put(Id1,new CustomerDTO("Sumit","9856985698","Noida",
				"sumit123@gmail.com"));
		customerList.put(Id2,new CustomerDTO("Yash","7886985698","Delhi",
				"yash123@gmail.com"));
	}
	public static HashMap<Integer,CustomerDTO> getStaticList() {
		return customerList;
	}
	public static void setStaticList(HashMap<Integer,CustomerDTO> staticList) {
		StaticDb.customerList = staticList;
	}
	
}
