package com.cg.bean;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.customException.CustomException;

public class AgeComponentTest {
	static AgeComponent obj;
	@Test
	public void testIsValidAge(){
		//fail("Not yet implemented");
		 obj=new AgeComponent();
		boolean flag = obj.isValidAge(23);
		assertTrue(flag);
	}
	
	@Test(expected = CustomException.class)
	public void testIsValid_veAge(){
		//fail("Not yet implemented");
		boolean flag = obj.isValidAge(-53);
		assertFalse(flag);
	}
	@Test
	public void testIsValidName(){
		//fail("Not yet implemented");
		boolean flag = obj.isValidName("Sumit");
		assertTrue(flag);
	}
	@BeforeClass
	public static void start()
	{
		obj=new AgeComponent();
		System.out.println("Call me");
	}
	@AfterClass
	public static void stop()
	{
		obj=null;
		System.out.println("Bye");
	}

}
