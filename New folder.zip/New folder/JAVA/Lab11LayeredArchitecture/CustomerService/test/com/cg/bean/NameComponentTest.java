package com.cg.bean;

import static org.junit.Assert.assertTrue;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

public class NameComponentTest {
	static NameComponent obj;
	@Test
	public void isName(){
		//fail("Not yet implemented");
		String namePattern="[A-Z][a-z]";
		String input="sumit,yash";
		Pattern pattern = Pattern.compile(input);
		Matcher matcher= pattern.matcher("Sumit");
		obj=new NameComponent();
		boolean flag = obj.isNameValid("Sumit");
		assertTrue(flag);
	}
	@BeforeClass
	public static void start()
	{
		obj=null;
		System.out.println("Call me");
	}
	@AfterClass
	public static void stop()
	{
		obj=null;
		System.out.println("Bye");
	}
}
