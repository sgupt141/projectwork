package com.cg.bean;

import com.cg.customer.dto.CustomerDTO;

public class CustomerTestDemo {
	public boolean isNameValid(String cust)
	{
		NameComponent name=new NameComponent();
		return name.isNameValid(cust);
	}
	public boolean isIdValid(int cust)
	{
		NameComponent name=new NameComponent();
		return name.isIdValid(cust);
	}
	public boolean isEmailValid(String cust)
	{
		NameComponent name=new NameComponent();
		return name.isEmailValid(cust);
	}
	public boolean isPhoneValid(String cust)
	{
		NameComponent name=new NameComponent();
		return name.isPhoneValid(cust);
	}
	public boolean isAddressValid(String cust)
	{
		NameComponent name=new NameComponent();
		return name.isPhoneValid(cust);
	}
}
