package com.cg.bean;
import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.customException.CustomException;

public class CustomerComponentTset {
	NameComponent obj= new NameComponent();
	@Test
	public void test1(){
		//fail("Not yet implemented");
		boolean flag = obj.isNameValid("Sumit");
		assertTrue(flag);
	}
	@Test
	public void test2(){
		//fail("Not yet implemented");
		boolean flag = obj.isIdValid(12);
		assertTrue(flag);
	}
	@Test
	public void test3(){
		//fail("Not yet implemented");
		boolean flag = obj.isPhoneValid("9897768985");
		assertTrue(flag);
	}
	@Test
	public void test4(){
		//fail("Not yet implemented");
		boolean flag = obj.isAddressValid("Noida");
		assertTrue(flag);
	}
	@Test
	public void test5(){
		//fail("Not yet implemented");
		boolean flag = obj.isEmailValid("sumit@gmail.com");
		assertTrue(flag);
	}
}
