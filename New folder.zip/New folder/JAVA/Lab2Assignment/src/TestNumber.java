
public class TestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n= Integer.parseInt(args[0]);
		if(n >= 0)
			System.out.println("The given number is positive number.");
		else
			System.out.println("The given number is negative number.");
	}

}
