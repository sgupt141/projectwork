import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

enum Gender
{
	M,F
}
class Person
{
	private String firstname;
	private String lastname;
	private Gender gender;
	private String phonenumber;
	Person(){}
	public String getFirstname()
	{
		return firstname;
	}
	public void setFirstname(String firstname)
	{
		this.firstname=firstname;
	}
	public String getLastname()
	{
		return lastname;
	}
	public void setLastname(String lastname)
	{
		this.lastname=lastname;
	}
	public Gender getGender()
	{
		return gender;
	}
	public void setGender(Gender gender)
	{
		this.gender=gender;
	}
	public String getNumber()
	{
		return phonenumber;
	}
	public void setNumber(String phonenumber)
	{
		this.phonenumber=phonenumber;
	}
	Person(String firstname, String lastname, Gender gender, String phonenumber)
	{
		this.firstname=firstname;
		this.lastname=lastname;
		this.gender=gender;
		this.phonenumber=phonenumber;
	}
	void details()
	{
		System.out.println("Person Details:");
		System.out.println("-------------");
		System.out.println("First Name: "+getFirstname());
		System.out.println("Last Name: "+ getLastname());
		System.out.println("Gender: "+getGender());
		System.out.println("Phone Number: "+ getNumber());
	}	
}
public class PersonMain {
	static int calcAge(LocalDate age)
	{
		LocalDate ld= LocalDate.now();		
		return Period.between(age, ld).getYears();
	}
	static String getFullName(String firstName, String lastName)
	{
		return firstName+lastName;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Person person = new Person("Sumit","Gupta",Gender.M,"9897768985");
		System.out.println("Enter date of birth in yyyy-mm-dd: ");
		int year=sc.nextInt();
		int month=sc.nextInt();
		int day=sc.nextInt();
		person.details();
		System.out.println("Full name of person is: "+getFullName("Sumit ","Gupta"));
		LocalDate dob=LocalDate.of(year, month, day);
		System.out.println("Age: "+calcAge(dob));		
	}

}
