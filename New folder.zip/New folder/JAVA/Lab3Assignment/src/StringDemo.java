import java.util.HashMap;
import java.util.Scanner;

class StringInput
{
	HashMap<Character,Integer> hm=new HashMap<>();
	public String addString(String str)
	{
		return str+str;
	}
	public String replaceString(String str)
	{
		String newString="";
		for(int i=0;i<str.length();i++)
		{
			if(i%2!=0)
			{
				newString=newString+'#';
			}
			else
			{
				newString+=str.charAt(i);
			}
		}
		return newString;
	}
	public String duplicateString(String str)
	{
		for(int i=0;i<str.length();i++)
		{  
			if(!hm.containsKey(str.charAt(i)))
			{
				hm.put(str.charAt(i), i);
			}
		}
		String str2="";
		for(int i=0;i<str.length();i++)
		{
			if(hm.containsKey(str.charAt(i)))
			{
				str2+=str.charAt(i);
				hm.remove(str.charAt(i));
			}
		}
		return str2;
	}
	public String upperCaseString(String str)
	{
		String newString1="";
		for(int i=0;i<str.length();i++)
		{
			if(i%2!=0)
			{  
				String ch= str.charAt(i)+"";
				newString1=newString1 + ch.toUpperCase();
			}
			else
			{
				newString1+=str.charAt(i);
			}
		}
		return newString1;
	}
}
public class StringDemo {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter string: \n");
		String string=scan.next();
		System.out.println("Enter your choice: \n"+
		    "1. Add the String to itself.\n"+   
		    "2. Replace odd positions with #\n"+
			"3. Remove duplicate characters in the String\n"+
			"4. Change odd characters to upper case");
		int ch=scan.nextInt();
		
		StringInput si =new StringInput();
		switch(ch)
		{
			case 1: System.out.println(si.addString(string));
			        break;
			case 2: System.out.println(si.replaceString(string));
					break;
			case 3: System.out.println(si.duplicateString(string));
					break;
			case 4: System.out.println(si.upperCaseString(string));
					break;
			default : System.out.println("Wrong Input");
					break;
		}
	}

}
