import java.util.Scanner;
class CheckString
{
	public boolean demoString(String string)
	{
		int flag=0;
		for(int i=0;i<string.length()-1;i++)
        {
			int temp1=string.charAt(i);
			int temp2=string.charAt(i+1);
			if(temp1>temp2)
			{
				flag=1;
			}
        }
			if(flag==0)
				return true;
			else
				return false;
	}
}
public class TestString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your String to check it is positive or not: ");
		String string=sc.next();
		CheckString cs=new CheckString();
		boolean temp=cs.demoString(string);
		if(temp==true)
			System.out.println(string+" is positive string.");
		else
			System.out.println(string+" is not positive string.");
		

	}

}
