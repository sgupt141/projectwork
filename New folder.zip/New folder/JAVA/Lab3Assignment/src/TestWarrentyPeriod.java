import java.time.LocalDate;
import java.util.Scanner;

public class TestWarrentyPeriod {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter purchase  date: \n");
		int day=sc.nextInt();
		int month=sc.nextInt();
		int year=sc.nextInt();
		System.out.println("Enter Warrenty period: \n");
		int warMonth=sc.nextInt();
		int warYear=sc.nextInt();
		LocalDate purchaseDate = LocalDate.of(year,month,day);
		LocalDate expiringDate = purchaseDate.plusMonths(warMonth);
		          expiringDate = expiringDate.plusYears(warYear);
		System.out.println("Warrenty Exp Date:- "+expiringDate.getDayOfMonth()+"-"+
				expiringDate.getMonthValue()+"-"+expiringDate.getYear());
	}
}
