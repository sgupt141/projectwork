import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class DateDurationTest {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter LocalDate1: \n");
		int day=sc.nextInt();
		int month=sc.nextInt();
		int year=sc.nextInt();
		System.out.println("Enter LocalDate2: \n");
		int day1=sc.nextInt();
		int month1=sc.nextInt();
		int year1=sc.nextInt();
		LocalDate startDate=LocalDate.of(year, month, day);
		LocalDate endDate=LocalDate.of(year1, month1, day1);
		Period period = startDate.until(endDate);
		System.out.println("-------");
		System.out.println("Days:- "+period.getDays()+"\nMonths:- "
		+period.getMonths()+"\nYears:- "+period.getYears());
		
	}

}
