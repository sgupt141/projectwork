import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

public class TestCollectionDemo {

	public static void main(String[] args) {
		String option ="";
		Scanner scan = new Scanner(System.in);
		ConcurrentHashMap<Long,Employee> hm=new ConcurrentHashMap<>();
		ArrayList<Float> arrList = new ArrayList<>();
		
		Set<Entry<Long,Employee>> entrySet=hm.entrySet();
		Employee e1=new Employee(111,"Sumit",1111.1F);
		Employee e2=new Employee(222,"Nishant",6666.6F);
		Employee e3=new Employee(666,"Sudhanshu",6666.6F);
		Employee e4=new Employee(777,"Yash",7777.7F);
		Employee e5=new Employee(555,"Amman",5555.5F);
		hm.put(9897768985L,e1);
		hm.put(9658458488L,e2);
		hm.put(8756895559L,e3);
		hm.put(9588441558L,e4);
		hm.put(9884565955L,e5);
		Collections.sort(arrList);
		//System.out.println(arrList);
		
		System.out.println("Employee Detais:- ");
		for(Entry entry : entrySet)
		{
		   System.out.println("PhoneNum: "+entry.getKey()+" Name: "
				   + entry.getValue());
		}
		do{
		System.out.println("Choose only one option: \n"+
					"1. Add new details\n"+
					"2. Delete any detail\n"+
					"3. Search name with phone number\n"+
					"4. Sort based on salary\n");
		int ch=scan.nextInt();
		switch(ch)
		{
		case 1: System.out.println("Enter employee Id: \n");
		  		int id=scan.nextInt();
		  		System.out.println("Enter employee name:= \n");
		  		String name=scan.next();
		  		System.out.println("Enter employee salary:= \n");
		  		float sal=scan.nextFloat();
		  		System.out.println("Enter employee phone number:= \n");
		  		Long phoneNo=scan.nextLong();
		  		Employee e6= new Employee(id,name,sal);
		  		hm.put(phoneNo,e6);
				for(Entry entry : entrySet)
				{
				   System.out.println("PhoneNum: "+entry.getKey()+" Name: "
						   				+ entry.getValue());
				}
		  		break;
		case 2: System.out.println("Enter person phoneNo"
						+ " which you want to delete \n");
				Long phoneNum=scan.nextLong();
				if(hm.containsKey(phoneNum))
				{
					Employee x = hm.get(phoneNum);
					arrList.remove(x.getEmpSal());
					hm.remove(phoneNum);
				}
				else
				{
					System.out.println("No record found.\n");
					break;
				}
				for(Entry entry : entrySet)
				{
				   System.out.println("PhoneNum :"+entry.getKey()+" Name: "
						   				+ entry.getValue());
				}
				break;
		case 3: System.out.println("Enter person name: \n");
				String searchName=scan.next();
				entrySet = hm.entrySet();
				for(Entry entry : entrySet)
				{
					Employee emp= (Employee)entry.getValue();
					
					if(emp.getEmpName().equalsIgnoreCase(searchName))
  					{
						 System.out.println(entry.getValue()+" : "+
								 "PhoneNum :"+entry.getKey());
  					}
					else
					{
						System.out.println("No record found.\n");
						break;
					}
				}
				break;		
		case 4: for(Entry entry: entrySet)
				{
					Employee emp = (Employee)entry.getValue();
					arrList.add(emp.getEmpSal());
				}
				Collections.sort(arrList);
				for(int i=0;i<arrList.size();i++)
				{
					float sortSal=arrList.get(i);
					for(Entry entry: entrySet)
					{
						Employee emp = (Employee)entry.getValue();
						float salary = emp.getEmpSal();
						if(salary==sortSal)
						{
							System.out.println(emp+"\n");
						}
					}
				}
				break;
		}
		System.out.println("Do you want to continue: Press YES \n");
		option = scan.next();
		}while(option.equalsIgnoreCase("yes"));
		System.exit(0);
	}
}
