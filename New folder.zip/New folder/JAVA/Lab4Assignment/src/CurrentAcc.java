
public class CurrentAcc extends Account 
{

	double overDraft;
	CurrentAcc(long accNum, double balance, String name, int age)
	{
		super(accNum,balance,name,age);
		overDraft=1000;
	}
	@Override
	public void withdraw(double amount)
	{
		if((this.getBalance()+overDraft)>amount)
		{
			if(amount>this.getBalance())
				this.overDraft=this.overDraft+this.getBalance()-amount;
			if(overDraft<1000)
				this.setBalance(0);
			else
				this.setBalance(this.getBalance()-amount);
			System.out.println("overdraft limit:  "+this.overDraft);
		}
		else
			System.out.println("Not enough fund and overdraft limit");
	}

}
