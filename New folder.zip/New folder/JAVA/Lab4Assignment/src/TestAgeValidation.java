
public class TestAgeValidation {
	public void isAgeValid(int age)
	{
		if(age<15)
			throw new CustomException("Age is less than 15.");
			
	}
}
