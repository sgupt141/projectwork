
public class SavingAcc extends Account 
{
	final double minBal;
	SavingAcc(long accNum, double balance, String name, int age)
	{
		super(accNum,balance,name,age);
		minBal=1000;
		
	}
	@Override
	public void withdraw(double amount)
	{
		if((this.getBalance()-amount)>minBal)
			this.setBalance(this.getBalance()-amount);
		else
			System.out.println("Not enough fund\n");
	}
}
