class Person{
	private String personName;
	private float personAge;
	Person(){}
	public String getPersonName() {
		return personName;
	}
	public void setPersonName(String personName) {
		this.personName = personName;
	}
	public float getPersonAge() {
		return personAge;
	}
	public void setPersonAge(float personAge) {
		this.personAge = personAge;
	}
	Person(String personName, float personAge)
	{
		this.personName=personName;
		this.personAge=personAge;
	}
	@Override
	public String toString() {
		return "\npersonName=" + personName + "\npersonAge=" + personAge+"\n";
	}
	
}

 public abstract class Account {
	private long accNum;
	private double balance;
	private Person accHolder;
	Account()
	{}
	Account(long accNum, double balance, String personName, int personAge) {
		//super();
		this.accNum = accNum;
		this.balance = balance;
		this.accHolder = new Person(personName, personAge);
	}
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
//	public Person getAccHolder() {
//		return accHolder;
//	}
//	public void setAccHolder(Person accHolder) {
//		this.accHolder = accHolder;
//	}
	public void deposite(double amount)
	{
		this.balance=this.balance+amount;
	}
	public void withdraw(double amount)
	{
		this.balance=this.balance-amount;
	}
//	double getBalance()
//	{
//		return this.balance;
//	}
	@Override
	public String toString() {
		return "accNum=" + accNum + 
				"\nbalance=" + balance
				+ accHolder.toString();
	}
	
}
