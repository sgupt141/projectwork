
public class CustomException extends RuntimeException {
	CustomException(String str)
	{
		super(str);
	}
}
