import java.util.Random;
import java.util.Scanner;

public class AccountMain {
		public static void main(String args[])
		{
			Scanner sc=new Scanner(System.in);
			TestAgeValidation valid=new TestAgeValidation();
			System.out.println("Enter Age of Smith:\n");
			Random random=new Random();
			try
			{
				int age =sc.nextInt();
				valid.isAgeValid(age);
			
			
			long accNum1=random.nextInt(200000000)+10000000;
			Account acc1= new SavingAcc(accNum1,2000,"Smith",age);

			System.out.println("current account open");
			System.out.println(acc1);
			acc1.deposite(2000);
			System.out.println("Current balance: "+acc1.getBalance()+"\n");
			acc1.withdraw(4500);
			System.out.println("Current balance: "+acc1.getBalance()+"\n");
			acc1.withdraw(200);
			System.out.println("Final Details of Smith:-\n");
			System.out.println(acc1.toString());
			}
			catch(CustomException e)
			{
				System.out.println(e);
			}
			try
			{
			long accNum2=random.nextInt(200000000)+10000000;
			System.out.println("Enter Age of Kathe:\n");
			int age1=sc.nextInt();
			valid.isAgeValid(age1);
			Account acc2= new SavingAcc(accNum2,3000,"Kathe",age1);
			System.out.println("saving account open");
			System.out.println(acc2);
			
			System.out.println("Saving balance: "+acc2.getBalance()+"\n");
			
			System.out.println("Final Details of Kathe:-\n");

			System.out.println(acc2);
			}
			catch(CustomException e)
			{
				System.out.println(e);
			}
		}
		
}
