
public class TestValidation {
	public void isFirstNameValid(String firstName)
	{
		if(firstName.equals(""))
			throw new CustomException("Firstname is empty.");
			
	}
	public void isLastNameValid(String lastName)
	{
		if(lastName.equals(""))
			throw new CustomException("LastName is empty.");
	}
}
