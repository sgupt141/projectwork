function validate()
{
    var amount=document.getElementById("amount").value;
    var rate=document.getElementById("instrate").value;
    var period=document.getElementById("period").value;
    if(amount>1500000)
    {
        document.getElementById("amount-error").innerHTML="should not exceed 15 lakhs";
        return false;
    }
    else{
        document.getElementById("amount-error").innerHTML="";
    }


    if(period< 15 && period>7)
    {
        document.getElementById("period-error").innerHTML="";
   

}
    else{
        document.getElementById("period-error").innerHTML="should not exceed 15 years or should not be below 7 years";
        return false; 
    
    }

    var interest=(amount*period*rate)/100;
    var totalamount=parseInt(amount)+interest;
    var monthinst=Math.round((interest/(period*12))*100)/100;
    document.getElementById("monthpay").value=monthinst;
    document.getElementById("totalpay").value=totalamount;
    document.getElementById("totalinst").value=interest;

    

}