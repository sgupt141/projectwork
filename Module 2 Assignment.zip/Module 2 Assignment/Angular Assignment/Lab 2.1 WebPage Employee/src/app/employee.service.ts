import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { Employeelist} from './Employelist';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  myEvent(){
    return 'Employee Service';
  }
  localurl:string='./assets/Employee.json';
  constructor(private http: HttpClient) { }
  httpOptions = {
    heade: new HttpHeaders({
      'content-Type': 'application.json'
    })
  }
  GetEmployeeList(): Observable<Employeelist>{
    return this.http.get<Employeelist>(this.localurl).pipe(retry(1),catchError(this.errorHand1))
  }
  errorHand1(error)
  {
    return throwError(error);
  }
}
