export class Employeelist{
    empId:string;
    empName:string;
    empSal:string;
    empDept:string;
}