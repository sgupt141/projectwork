export class Employee{
    id:string;
    name:string;
    salary:string;
    department:string;
}