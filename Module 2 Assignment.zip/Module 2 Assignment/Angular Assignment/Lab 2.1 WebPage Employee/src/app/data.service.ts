import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Employee } from './Employee';
import {retry,catchError} from  'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  localUrl:string='./assets/employees.json';
  constructor(private http:HttpClient) { }
  getEmployee():Observable<Employee>{
    return this.http.get<Employee>(this.localUrl).pipe(retry(1),catchError(()=>{
      return throwError("Error Reading JSON");
    }));
  }
}
