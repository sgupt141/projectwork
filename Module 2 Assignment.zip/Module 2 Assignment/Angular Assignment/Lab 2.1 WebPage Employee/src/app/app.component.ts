import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Angular 2 Operation';
  empId:string;
  empName:string;
  empSal:string;
  empDept:string;
  employeelist:any[];
  data :Object;
  constructor(private ds: EmployeeService){}
  ngOnInit(){
    this.loadData();
  }
  loadData(){
    return this.ds.GetEmployeeList().subscribe((data: any) =>{
      this.employeelist=data;
    })
  }
  public addEmp(){
    this.data=new Object();
    this.empId = (<HTMLInputElement>document.getElementById("id")).value;
    this.empName = (<HTMLInputElement>document.getElementById("name")).value;
    this.empSal = (<HTMLInputElement>document.getElementById("salary")).value;
    this.empDept = (<HTMLInputElement>document.getElementById("dept")).value;
    this.data["empId"]=this.empId;
    this.data["empName"]=this.empName;
    this.data["empSal"]=this.empSal;
    this.data["empDept"]=this.empDept;
    this.employeelist.push(this.data);
    (<HTMLInputElement>document.getElementById("id")).value="";
    (<HTMLInputElement>document.getElementById("name")).value="";
    (<HTMLInputElement>document.getElementById("salary")).value="";
    (<HTMLInputElement>document.getElementById("dept")).value="";
    
  }
  public delete(empId){
    for(var i=0;i<this.employeelist.length;i++)
    {
      if(this.employeelist[i].empId==empId)
      {
        this.employeelist.splice(i,1)
      }
    }
    alert('Data deleted');
  }
  public updateEmp(empId,empName,empSal,empDept){
    this.empId = (<HTMLInputElement>document.getElementById("id1")).value=empId;
    this.empName = (<HTMLInputElement>document.getElementById("name1")).value=empName;
    this.empSal = (<HTMLInputElement>document.getElementById("salary1")).value=empSal;
    this.empDept = (<HTMLInputElement>document.getElementById("dept1")).value=empDept;
    for(var i=0;i<this.employeelist.length;i++)
    {
      if(this.employeelist[i].empId==empId)
      {
        this.employeelist.splice(i,1)
      }
    }
    
  }
  public update(){
    this.data=new Object();
    this.empId = (<HTMLInputElement>document.getElementById("id1")).value;
    this.empName = (<HTMLInputElement>document.getElementById("name1")).value;
    this.empSal = (<HTMLInputElement>document.getElementById("salary1")).value;
    this.empDept = (<HTMLInputElement>document.getElementById("dept1")).value;
    this.data["empId"]=this.empId;
    this.data["empName"]=this.empName;
    this.data["empSal"]=this.empSal;
    this.data["empDept"]=this.empDept;
    this.employeelist.push(this.data);
    (<HTMLInputElement>document.getElementById("id1")).value="";
    (<HTMLInputElement>document.getElementById("name1")).value="";
    (<HTMLInputElement>document.getElementById("salary1")).value="";
    (<HTMLInputElement>document.getElementById("dept1")).value="";
    alert('Data updated');
  }
}
