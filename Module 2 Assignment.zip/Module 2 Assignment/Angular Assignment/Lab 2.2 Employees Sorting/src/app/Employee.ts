export class Employee{
    empId:string;
    empName:string;
    empSal:string;
    empDep:string;
}