import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Lab22';
  empArray=[];
  constructor(private empService:EmployeeService){}
  ngOnInit(){
    this.empService.getEmpdata().subscribe(data=>this.empArray=data);
  }
  public idSort( ){
  this.empArray.sort((a,b)=>(a.empId>b.empId) ? 1 : -1);
    
  }
  public nameSort(){
    this.empArray.sort((a,b)=>a.empName.localeCompare(b.empName));
  }
  public salSort( ){
    this.empArray.sort((a,b)=>(a.empSal>b.empSal) ? 1 : -1);
    }
    public deptSort(){
      this.empArray.sort((a,b)=>a.empDep.localeCompare(b.empDep));
    }
}
