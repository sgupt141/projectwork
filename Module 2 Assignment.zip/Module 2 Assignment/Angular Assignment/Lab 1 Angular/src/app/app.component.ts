import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular 2 Operation';
  id:Number;
  name:string;
  salary:number;
  dept:string
  myEvent(){
    alert(this.id+" "+this.name+" "+this.salary+" "+this.dept);
  }
}
