export class MovieData
{
    movieName:any;
    rating:any;
    genre:any;
constructor(name,rating,genre)
{
this.movieName=name;
this.rating=rating;
this.genre=genre;
}
}