import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { MovieData } from '../MovieData';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  constructor(public ap:AppComponent) { }

  ngOnInit(): void {
  }
genre12:any;
arr:MovieData[]=[];
t:boolean=false;
SearchOperation()
{
  this.ap.b=true;
  console.log(this.ap.b);
  this.arr=[];
 for(let i=0;i<this.ap.array.length;i++)
 {
   if(this.ap.array[i].genre==this.genre12)
   {
     this.arr.push(this.ap.array[i]);
   }
 }
 this.ap.arr12=this.arr;
 this.ap.b=false;
}

}
