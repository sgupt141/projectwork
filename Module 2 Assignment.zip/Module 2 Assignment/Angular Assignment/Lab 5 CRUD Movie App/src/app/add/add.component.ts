import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../app.component';
import { MovieData } from '../MovieData';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(public ap:AppComponent) { }

  ngOnInit(): void {

  }
   movieName:any;
   movieRating:any;
   genre:any;

  temp:MovieData[]=[];
  AddOperation()
  {
    this.ap.b=true;
    if(this.movieName==null)
    {
      alert("Please Enter the Movie Name");
      return 0;
    }
   else if(this.movieRating==null)
    {
      alert("Please Enter the Movie Rating");
      return 0;
    }
   else if(this.genre==null)
    {
      alert("Please Select the Movie Genre");
      return 0;
    }
    else
    {
    let obj=new MovieData(this.movieName,this.movieRating,this.genre);
    this.ap.array.push(obj);
    this.movieName=null;
    this.movieRating=null;
   this.genre=null;

    }
  }

}
