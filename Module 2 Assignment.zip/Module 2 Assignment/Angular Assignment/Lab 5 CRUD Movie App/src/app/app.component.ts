import { Component, OnInit } from '@angular/core';
import { MovieService } from './movie.service';
import { MovieData } from './MovieData';
import { SearchComponent } from './search/search.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'movies';
  array:MovieData[]=[];
  b:boolean=true;
  arr12:MovieData[]=[];
  constructor(private ds:MovieService)
  {

  }
  ngOnInit()
  {
   this.GetMovies(); 
  }
  GetMovies()
  {
    this.ds.getMovie().subscribe((data:any)=>{this.array=data;})
  }
}
