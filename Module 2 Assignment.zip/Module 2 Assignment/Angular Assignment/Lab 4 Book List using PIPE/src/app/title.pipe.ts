import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'title'
})
export class TitlePipe implements PipeTransform {

  transform(value: any[], ...args: any[]): any[] {
    let tempId:any=args[0];
    let i:number;
    
    if(tempId===undefined||tempId==""){
      value=args[1];
    }
    else{
    value=[];
    for(i=0;i<args[1].length;i++){
      if((args[1][i]["title"].toLowerCase()).includes(tempId.toLowerCase()) ){
        value.push(args[1][i]);
      }
    }
  }
    return value;
  }

}
