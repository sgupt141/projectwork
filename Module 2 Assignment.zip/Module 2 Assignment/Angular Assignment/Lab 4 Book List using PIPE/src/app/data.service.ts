import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Localbook } from './Localbook';
import { Observable, throwError } from 'rxjs';
import { retry,catchError } from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class DataService {
  data: Object;
  localurl: string = './assets/booklist.json';
  constructor(private http: HttpClient) { }
  

GetLocalBooks(): Observable<Localbook>{
  return this.http.get<Localbook>(this.localurl).pipe(retry(1),catchError(this.errorHandl));
}

errorHandl(error){
  
 return throwError("error");
}
}