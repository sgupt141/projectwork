import { YearPipe } from './year.pipe';

describe('YearPipe', () => {
  it('create an instance', () => {
    const pipe = new YearPipe();
    expect(pipe).toBeTruthy();
  });
});
