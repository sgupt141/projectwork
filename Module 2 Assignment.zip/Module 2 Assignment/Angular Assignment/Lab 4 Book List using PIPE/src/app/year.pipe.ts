import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'year'
})
export class YearPipe implements PipeTransform {

  transform(value: any[], ...args: any[]): any[] {
    let tempId:any=args[0];
    let i:number;
    
    if(tempId===undefined||tempId==null){
      value=args[1];
    }
    else{
    value=[];
    for(i=0;i<args[1].length;i++){
      if(args[1][i]["year"]===tempId){
        value.push(args[1][i]);
      }
    }
  }
    return value;
  }

}
