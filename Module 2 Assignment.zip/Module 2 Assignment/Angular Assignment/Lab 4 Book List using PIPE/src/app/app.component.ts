
import { DataService } from './data.service';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  constructor(private ds : DataService){};
  temp1:number;
  temp2:string;
  temp3:string;
  temp4:number;
  update:boolean=false;
  flag1:boolean=false;
  flag2:boolean=false;
  flag3:boolean=false;
  flag4:boolean=false;
  title = 'assignment4';
  localbookList: any[]=[];
  tempbookList: any[]=[];
  ngOnInit(){
    
    this.loadlocalbooks();
  }
 
 loadlocalbooks() {
   this.ds.GetLocalBooks().subscribe( (data : any) =>{ this.localbookList=data;});
   this.ds.GetLocalBooks().subscribe( (data : any) =>{ this.tempbookList=data;});
   }
   valID(){
    this.flag1=true;
    this.flag2=false;
    this.flag3=false;
    this.flag4=false;
   }

   valName(){
    this.flag1=false;
    this.flag2=true;
    this.flag3=false;
    this.flag4=false;
  }
  valAuthor(){
    this.flag1=false;
    this.flag2=false;
    this.flag3=true;
    this.flag4=false;
  }
  valYear(){
    this.flag1=false;
    this.flag2=false;
    this.flag3=false;
    this.flag4=true;
  }
   
}
