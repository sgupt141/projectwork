import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataService } from './data.service';
import { IdPipe } from './id.pipe';
import { YearPipe } from './year.pipe';
import { TitlePipe } from './title.pipe';
import { AuthorPipe } from './author.pipe';
import {FormsModule} from '@angular/forms'
@NgModule({
  declarations: [
    AppComponent,
    IdPipe,
    YearPipe,
    TitlePipe,
    AuthorPipe
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [DataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
