export class Localbook {
    id:string;
    title:string;
    year:string;
    author:string;
}