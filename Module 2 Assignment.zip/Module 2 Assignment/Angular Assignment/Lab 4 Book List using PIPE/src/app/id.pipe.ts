import { Pipe, PipeTransform } from '@angular/core';
import { Localbook } from './Localbook';

@Pipe({
  name: 'id'
})
export class IdPipe implements PipeTransform {

  transform(value: any[], ...args: any[]): any {
    let tempId:number=args[0];
    let i:number;
    
    if(tempId===undefined||tempId==null){
      value=args[1];
    }
    else{
    value=[];
    for(i=0;i<args[1].length;i++){
      if(args[1][i]["id"]===tempId){
        value.push(args[1][i]);
      }
    }
  }
    return value;
  }
}
