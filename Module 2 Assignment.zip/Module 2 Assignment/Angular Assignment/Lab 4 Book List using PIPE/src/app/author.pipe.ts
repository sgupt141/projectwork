import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'author'
})
export class AuthorPipe implements PipeTransform {

  transform(value: any[], ...args: any[]): any[] {
    let tempId:any=args[0];
    let i:number;
    
    if(tempId===undefined||tempId==""){
      value=args[1];
    }
    else{
    value=[];
    for(i=0;i<args[1].length;i++){
      if((args[1][i]["author"].toLowerCase()).includes(tempId.toLowerCase())){
        value.push(args[1][i]);
      }
    }
  }
    return value;
  }

}
