"use strict";
exports.__esModule = true;
var basicphone_1 = require("./basicphone");
var smartphone_1 = require("./smartphone");
var mobiles = [];
var mobile1 = new basicphone_1.BasicPhone(1001, "Nokia", 10897);
var mobile2 = new smartphone_1.SmartPhone(10003, "samsung", 162725);
mobiles.push(mobile1);
mobiles.push(mobile2);
for (var i = 0; i < mobiles.length; i++) {
    console.log(mobiles[i].printMobileDetail());
}
