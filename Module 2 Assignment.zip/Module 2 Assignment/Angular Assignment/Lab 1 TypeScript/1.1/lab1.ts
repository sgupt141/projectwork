import {mobile} from './mobile'
import { BasicPhone } from './basicphone'
import { SmartPhone } from './smartphone';
let mobiles: Array<mobile>=[];

 let  mobile1:mobile=new BasicPhone(1001,"Nokia",10897);
  let mobile2:mobile=new SmartPhone(10003,"samsung",162725);
    mobiles.push(mobile1);
    mobiles.push(mobile2);
for(var i=0;i<mobiles.length;i++)
{
    console.log(mobiles[i].printMobileDetail())
}
   