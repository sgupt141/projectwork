"use strict";
exports.__esModule = true;
var mobile = /** @class */ (function () {
    function mobile(mobileId, mobileName, mobileCost) {
        this.mobileId = mobileId;
        this.mobileName = mobileName;
        this.mobileCost = mobileCost;
    }
    mobile.prototype.printMobileDetail = function () {
    };
    return mobile;
}());
exports.mobile = mobile;
