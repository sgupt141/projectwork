import {mobile} from './mobile'
export class SmartPhone extends mobile{
    mobileType:string;

    printMobileDetail()
    {
       console.log(this.mobileId+" "+this.mobileCost+" "+this.mobileName+" "+this.mobileType);
    }
    constructor (mobileId:number , mobileName:string , mobileCost:number )
    {
        super(mobileId , mobileName , mobileCost );
        
        this.mobileType="Smart Mobile";
    }

}